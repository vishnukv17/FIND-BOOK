package com.cg.findbook.service;
import java.util.ArrayList;
import java.util.List;

import com.cg.findbook.dao.CustomerRepository;
import com.cg.findbook.dao.CustomerRepositoryImpl;
import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Customer;
import com.cg.findbook.exceptions.BookDetailNotFoundException;
import com.cg.findbook.exceptions.ConnectionException;
import com.cg.findbook.exceptions.CustomerDetailNotFoundException;
import com.cg.findbook.exceptions.DataModificationException;
import com.cg.findbook.exceptions.DataRetrievalException;
/** @author vishkv
 * dated: 2019-04-10 
 * Service Layer Implementation. */
public class CustomerServiceImpl implements CustomerService{
	/*
	 * The static variables customerCount,bookCount and addressCount are used to generate ID for respected entities. These are initialized 
	 * to a particular value. 
	 */
	
	private static int bookCount=1000;
	private static int customerCount=100;
	private static int addressCount=10000;
	private CustomerRepository  repository;
	public  CustomerServiceImpl() {
		repository=new CustomerRepositoryImpl();
	}
	/** 
	 	Last modified on 2019-05-02
	  	The add() Method is used to add a new Customer */
	public Customer add(Customer customer) throws ConnectionException {
		customer.getAddress().setId(addressCount);
		addressCount++;
		customer.setId(customerCount);
		customerCount++;
		customer=repository.save(customer);
		if(customer!=null)
			return customer;
		throw new DataModificationException("Data not added!");
	}

	/** 
	Last modified on 2019-05-02
  	The assignBookToCustomer() Method is used to add a new Book and assign that book to the mentioned customer */
	public Customer assignBookToCustomer(Book book, int customerId) throws CustomerDetailNotFoundException, ConnectionException {
		
		Customer customer=repository.findCustomerById(customerId);
		if(customer!=null) {
			book.setId(bookCount);
			bookCount++;
			List<Book> bookList=new ArrayList<Book>();
			//retrieve the existing books and add the new book to the list
			if(!customer.getBooks().isEmpty())
				bookList=customer.getBooks();
			bookList.add(book);
			customer.setBooks(bookList);
			return repository.save(customer);
		}
		throw new CustomerDetailNotFoundException("Id not found!");
	}

	/** 
	Last modified on 2019-05-02
  	The searchCustomersByBookName() Method is used to search the customers who have a particular book: It is a keyword search */
	public List<Customer> searchCustomersByBookName(String bookName) throws CustomerDetailNotFoundException, ConnectionException, DataRetrievalException {
		if(repository.findCustomersByBook(bookName).isEmpty())
			throw new CustomerDetailNotFoundException("No match found!");
		return repository.findCustomersByBook(bookName);
	}

	/**
	Last modified on 2019-05-02
  	The searchCustomersByCategory() Method is used to search the customers who have a particular category book */
	public List<Customer> searchCustomersByCategory(String category) throws CustomerDetailNotFoundException, ConnectionException, DataRetrievalException {
		
		if(repository.findCustomersByCategory(category).isEmpty())
			throw new CustomerDetailNotFoundException("No match found!");
		return repository.findCustomersByCategory(category);
		
	}

	/** 
	Last modified on 2019-05-02
  	The searchBooksByCategory() Method is used to search the books those belong to a particular category */
	public List<Book> searchBooksByCategory(String category) throws BookDetailNotFoundException, ConnectionException, DataRetrievalException {
		
		if(repository.findBooksByCategory(category).isEmpty())
			throw new BookDetailNotFoundException("No books found in this category!");
		return repository.findBooksByCategory(category);
	}

	/** 
	Last modified on 2019-05-02
  	The getAllBooks() Method is used to return all the books stored */
	public List<Book> getAllBooks() throws BookDetailNotFoundException, ConnectionException, DataRetrievalException {
		
		if(repository.getAllBooks().isEmpty())
			throw new BookDetailNotFoundException("No books found!");
		return(repository.getAllBooks());
	}
}
