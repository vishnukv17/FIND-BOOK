/** @author vishkv
 * CustomerDetailNotFoundException is raised when user searches for customer(s) and no match is found.
 * dated: 2019-04-15
 */
package com.cg.findbook.exceptions;

@SuppressWarnings("serial")
public class CustomerDetailNotFoundException extends Exception {
	
	public CustomerDetailNotFoundException() {
		super();
	}
	public CustomerDetailNotFoundException(String exceptionMessage) {
		super(exceptionMessage);
	}

}
