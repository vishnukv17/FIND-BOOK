/** @author vishkv
 * BookDetailNotFoundException is raised when user searches for books and no match is found.
 * dated: 2019-04-15
 */
package com.cg.findbook.exceptions;

@SuppressWarnings("serial")
public class BookDetailNotFoundException extends Exception{
	public BookDetailNotFoundException() {
		
	}
	public BookDetailNotFoundException(String exceptionMessage) {
		super(exceptionMessage);
	}


}
