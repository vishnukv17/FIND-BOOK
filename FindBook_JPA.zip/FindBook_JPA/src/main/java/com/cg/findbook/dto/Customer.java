package com.cg.findbook.dto;


/**
 * @author vishkv
 * dated: 2019-04-05
 * Customer POJO. Contains Customer information. Mapped to table named customer
 */
import java.math.BigInteger;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="customer")
public class Customer {

	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", updatable = false, nullable = false)
	private int id;
	private String name;
	private String email;
	private BigInteger phone;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="address_id",unique=true)
	private Address address;
	@OneToMany(cascade = CascadeType.ALL,orphanRemoval=true)
	@JoinColumn(name="customer_id")
	private List<Book> books;
	public Customer() {
		this.id = 0;
		this.name = null;
		this.email = null;
		this.phone = null;
		this.address = null;
		this.books = null;
		
	}
	public Customer(int id,String name, String email, BigInteger phone, Address address, List<Book> books) {
		super();
		this.id=id;
		this.name = name;
		this.email = email;
		this.phone = phone;
		this.address = address;
		this.books = books;
	}
	public Customer(String name, String email, BigInteger phone, Address address, List<Book> books) {
		super();
	
		this.name = name;
		this.email = email;
		this.phone = phone;
		this.address = address;
		this.books = books;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public BigInteger getPhone() {
		return phone;
	}
	public void setPhone(BigInteger phone) {
		this.phone = phone;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public List<Book> getBooks() {
		return books;
	}
	public void setBooks(List<Book> books) {
		this.books = books;
	}
	@Override
	public String toString() {
		return "Customer: \n id=" + id + "\n name=" + name + ",\n email=" + email + ",\n phone=" + phone + ",\n address="
				+ address + ",\n books=" + books ;
	}
	
}
