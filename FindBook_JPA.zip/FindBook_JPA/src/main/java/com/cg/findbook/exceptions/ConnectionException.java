/** @author vishkv
 * ConnectionException is raised when there is some failure in establishing connection with database.
 * dated: 2019-04-20
 */
package com.cg.findbook.exceptions;

public class ConnectionException extends Exception {
	public ConnectionException() {
	
	}
	public ConnectionException(String message) {
		super(message);
	}

}
