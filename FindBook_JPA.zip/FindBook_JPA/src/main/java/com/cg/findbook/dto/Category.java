/**
 * @author vishkv
 * dated: 2019-04-05
 * Categories are created as Enum. User has to choose one among them.
 */
package com.cg.findbook.dto;

public enum Category {
	FICTION,CLASSICS,EDUCATION,JOURNALS,SCIENCE;
}
