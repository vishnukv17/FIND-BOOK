package com.cg.findbook.service;

import java.util.List;

import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Customer;
import com.cg.findbook.exceptions.BookDetailNotFoundException;
import com.cg.findbook.exceptions.ConnectionException;
import com.cg.findbook.exceptions.CustomerDetailNotFoundException;
import com.cg.findbook.exceptions.DataRetrievalException;



public interface CustomerService {

	Customer add(Customer customer) throws ConnectionException  ;
	Customer assignBookToCustomer(Book book,int id) throws CustomerDetailNotFoundException, ConnectionException;
	List<Customer> searchCustomersByBookName(String bookName) throws CustomerDetailNotFoundException, ConnectionException, DataRetrievalException;
	List<Customer> searchCustomersByCategory(String category) throws CustomerDetailNotFoundException, ConnectionException, DataRetrievalException;
	List<Book> searchBooksByCategory(String category) throws BookDetailNotFoundException, ConnectionException, DataRetrievalException;
	List<Book> getAllBooks() throws BookDetailNotFoundException, ConnectionException, DataRetrievalException;
}
