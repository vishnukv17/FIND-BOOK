/** @author vishkv
 * DataModificationException is raised when any select operation fails. The corresponding details regarding exception is 
 * written into log file.
 * dated: 2019-04-30
 */
package com.cg.findbook.exceptions;

@SuppressWarnings("serial")
public class DataRetrievalException extends RuntimeException {
	public DataRetrievalException() {
	
	}
	public DataRetrievalException(String message){
		super(message);
	}

}
