package com.cg.findbook.dao;

public interface DBQueries {
		
		public static final String selectAllBooks="select book from Book book";
		public static final String selectBooksByCategory="select book from Book book where book.category=?";
		public static final String selectCustomerByBook="select distinct customer FROM Customer customer, IN(customer.books) book WHERE book.name like ?)";
		public static final String selectCustomerByCategory="select distinct customer FROM Customer customer, IN(customer.books) book WHERE book.category=?";
		
		
		
		//select c.id,c.name,c.email,c.phone,a.houseNo,a.city,a.state,a.pincode from customer c inner join address a on c.address_id=a.address_id where c.id in(select b.customer_id from book b where b.name like "%Shiva%");
	

}
