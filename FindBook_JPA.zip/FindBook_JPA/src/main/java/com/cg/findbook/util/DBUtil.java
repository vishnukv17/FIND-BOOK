/** @author vishkv
 * Created on 2019-04-20
 * DBUtil is used to establish connection with database. It also create entity manager object.
 */
package com.cg.findbook.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.findbook.exceptions.ConnectionException;

public class DBUtil {
	static EntityManager em=null;
	public static EntityManager getConnection() throws ConnectionException {
		try {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("findbook");
		em=emf.createEntityManager();
		em.getTransaction().begin();
		}catch(Exception e) {
			throw new ConnectionException("Connection Not Established!");
		}
		return em;
	}

}
