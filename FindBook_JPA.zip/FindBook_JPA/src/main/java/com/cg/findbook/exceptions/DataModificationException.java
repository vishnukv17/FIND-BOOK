/** @author vishkv
 * DataModificationException is raised when any insert or update operation fails. The corresponding details regarding exception is 
 * written into log file.
 * dated: 2019-04-30
 */
package com.cg.findbook.exceptions;

public class DataModificationException extends RuntimeException {
	public DataModificationException() {
	
	}
	public DataModificationException(String message) {
		super(message);
	}

}
