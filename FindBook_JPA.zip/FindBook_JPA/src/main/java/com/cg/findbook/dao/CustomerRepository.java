package com.cg.findbook.dao;

import java.util.List;

import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Customer;
import com.cg.findbook.exceptions.ConnectionException;
import com.cg.findbook.exceptions.DataRetrievalException;

public interface CustomerRepository {
	
	Customer save(Customer customer) throws ConnectionException;
	List<Customer> findCustomersByCategory(String category) throws ConnectionException, DataRetrievalException;
	List<Customer> findCustomersByBook(String bookName) throws ConnectionException, DataRetrievalException;
	Customer findCustomerById(int id) throws ConnectionException;
	List<Book> getAllBooks() throws ConnectionException, DataRetrievalException;
	List<Book> findBooksByCategory(String category) throws ConnectionException, DataRetrievalException;

}
