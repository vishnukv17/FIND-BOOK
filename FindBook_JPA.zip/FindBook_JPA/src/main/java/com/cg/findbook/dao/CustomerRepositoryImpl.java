
/**
 * @author vishkv
 * Repository Implementation. Contains methods that either retrieve data or write data from/to the database.
 * The errors are logged to a mentioned file. 
 */
package com.cg.findbook.dao;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;

import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Customer;
import com.cg.findbook.exceptions.ConnectionException;
import com.cg.findbook.exceptions.DataModificationException;
import com.cg.findbook.exceptions.DataRetrievalException;
import com.cg.findbook.util.DBUtil;

public class CustomerRepositoryImpl implements CustomerRepository{

	static Logger log = Logger.getLogger(CustomerRepositoryImpl.class.getName());
	/* 
 	Last modified on 2019-05-03
  	The save() Method is used to save customer and book to the database */
	
	public Customer save(Customer customer) throws ConnectionException {
		EntityManager em=DBUtil.getConnection();
		try {
			if((em.find(Customer.class, customer.getId())==null)) {
				em.persist(customer);
				em.getTransaction().commit();
				return customer;
			}
			else if((em.find(Customer.class, customer.getId())!=null)&&(!customer.getBooks().isEmpty())){
				em.merge(customer);
				em.getTransaction().commit();
				return customer;
			}
		}catch(Exception e) {
			log.error(e.toString());
			throw new DataModificationException("Data not added!");
			
		}
		finally {
			if(em!=null)
				em.close();
		}
		return null;
		
	}
	/** 
 	Last modified on 2019-05-02
  	The following find**() Methods, and getAllBooks() method  are used to find customer(s) and/or books stored in database*/
	
	/*	Performs category search. Accepts category as parameter and returns a list of Customer
 	who has a book that falls in the particular category */
	public List<Customer> findCustomersByCategory(String category) throws ConnectionException, DataRetrievalException {
		EntityManager em=DBUtil.getConnection();
		try {
		TypedQuery<Customer> query=em.createQuery(DBQueries.selectCustomerByCategory,Customer.class);
		query.setParameter(1,category);
		List<Customer> customers=query.getResultList();
		return customers;
		}catch (Exception e) {
			log.error(e.getMessage());
			throw new DataRetrievalException("Data retrieval failed!");
		}
		finally {
			em.close();
		}
		
	}

	/*	Performs keyword search. Accepts book name(String) as parameter and returns a list of Customer
	 	who has a book that matches the keyword */
	public List<Customer> findCustomersByBook(String bookName) throws ConnectionException, DataRetrievalException {
		EntityManager em=DBUtil.getConnection();
		try {
		
		TypedQuery<Customer> query=em.createQuery(DBQueries.selectCustomerByBook,Customer.class);
		query.setParameter(1,"%"+bookName+"%");
		List<Customer> customers=query.getResultList();
		return customers;
		}catch (Exception e) {
			log.error(e.getMessage());
			throw new DataRetrievalException("Data retrieval failed!");
		}
		finally {
		em.close();
		}
	}
	
	/*	Performs Id search. Accepts customer id(integer) as parameter and returns customer if a match is found.
 	who has a book that matches the keyword */
	public Customer findCustomerById(int customerId) throws ConnectionException {
		EntityManager em=DBUtil.getConnection();
		Customer customer=em.find(Customer.class,customerId);
		em.close();
		return customer;
	}

	//	Returns list of all Books 
	public List<Book> getAllBooks() throws ConnectionException, DataRetrievalException {
		EntityManager em=DBUtil.getConnection();
		try {
		TypedQuery<Book> query=em.createQuery(DBQueries.selectAllBooks,Book.class);
		List<Book> bookData=query.getResultList();
		return bookData;
		}catch (Exception e) {
			log.error(e.getMessage());
			throw new DataRetrievalException("Data retrieval failed!");
		}finally {
			em.close();
		}
	}

	//Returns a list of Books that fall in a particular category.
	public List<Book> findBooksByCategory(String category) throws ConnectionException, DataRetrievalException {
		EntityManager em=DBUtil.getConnection();
		try {
		TypedQuery<Book> query=em.createQuery(DBQueries.selectBooksByCategory,Book.class);
		query.setParameter(1,category);
		List<Book> bookData=query.getResultList();
		return bookData;
		}catch (Exception e) {
			log.error(e.getMessage());
			throw new DataRetrievalException("Data retrieval failed!");
		}finally {
			em.close();
		}
		
	}

}
