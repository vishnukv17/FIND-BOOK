import {Component,OnInit} from '@angular/core';
import {CustomerService} from './app.customerservice';
import {Customer} from './app.customer';
import {Address} from './app.address';
import {Book} from './app.book';
import {FormControl,FormArray,FormBuilder,FormGroup,Validators} from '@angular/forms';
@Component({
    selector:'cust-app',
    templateUrl: 'app.searchbookcat.html'
})
export class SearchBook implements OnInit{
    category:string[];
   books:Book[];
   searchForm=new FormGroup({
    cato:new FormControl('')
});
    constructor(private custservice:CustomerService){}
    ngOnInit(){
        //this.proservice.getAllProduct().subscribe((data:Customer[])=>this.products=data);
        this.getCategory();
    }
    search(){
        this.custservice.searchBookByCategory(this.searchForm.value.cato).subscribe((data:any)=>this.books=data);
    }
    getCategory(){
        this.custservice.getCategory().subscribe((data:any)=> this.category=data);
    };
}