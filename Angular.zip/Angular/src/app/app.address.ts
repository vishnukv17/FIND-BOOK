export class Address{
    pincode:number;
    area:string;
    city:string;
    state:string;
    houseNo:string;
} 