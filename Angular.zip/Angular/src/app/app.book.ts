export class Book{
    id:number;
    name:string;
    author:string;
    categiry:string;
    publisher:string;
}