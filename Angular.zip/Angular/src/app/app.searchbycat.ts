import {Component,OnInit} from '@angular/core';
import {CustomerService} from './app.customerservice';
import {Customer} from './app.customer';
import {Address} from './app.address';
import {Book} from './app.book';
import {FormControl,FormArray,FormBuilder,FormGroup,Validators} from '@angular/forms';

@Component({
    selector:'cust-app',
    templateUrl: 'app.searchbycat.html'
})
export class SearchByCategory implements OnInit{
    category:string[];
    searchForm=new FormGroup({
        cato:new FormControl('')
    });
   customers:Customer[];
   //cato:any;
    constructor(private custservice:CustomerService){}
    ngOnInit(){
        //this.proservice.getAllProduct().subscribe((data:Customer[])=>this.products=data);
        this.getCategory();
    }
    search(){
        this.custservice.searchByCategory(this.searchForm.value.cato).subscribe((data:any)=>this.customers=data);
    }
    getCategory(){
        this.custservice.getCategory().subscribe((data:any)=> this.category=data);
    };
}