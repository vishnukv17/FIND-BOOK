import {Injectable} from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Observable,throwError} from 'rxjs';
import {HttpErrorResponse} from '@angular/common/http';
import { ErrorHandler } from '@angular/core';
import {catchError,retry} from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})
export class CustomerService {

    constructor(private http:HttpClient){}
    getAllBooks(){
        return this.http.get("http://localhost:9095/fb/showallbooks");
    }
    addCustomer(cust:any){
        let input=new FormData();
        input.append("name",cust.name);
        input.append("email",cust.email);
        input.append("phone",cust.phone);
        input.append("address.houseNo",cust.houseNo);
        input.append("address.area",cust.area);
        input.append("address.city",cust.city);
        input.append("address.state",cust.state);
        input.append("address.pincode",cust.pincode);
        
        return this.http.post("http://localhost:9095/fb/add",input);
    }
    getCategory(){
        return this.http.get("http://localhost:9095/fb/getcategory");
    }
    addBook(model:any){
        let input=new FormData();
        input.append("name",model.name);
        input.append("author",model.author);
        input.append("publisher",model.publisher);
        input.append("category",model.category);
        input.append("cid",model.cid);
        return this.http.post("http://localhost:9095/fb/addbook",input);
    }
    searchByName(bookname:string){
        let params = new HttpParams().set("bname",bookname);
        
        return this.http.get("http://localhost:9095/fb/searchcustbname",{params: params}).pipe(retry(1),catchError(this.handleError));
    }
    searchBookByCategory(category:string){
        let params = new HttpParams().set("category",category);
        return this.http.get("http://localhost:9095/fb/searchbookbycat",{params: params});
    }
    searchByCategory(category:string){
        let params = new HttpParams().set("category",category);
        return this.http.get("http://localhost:9095/fb/searchcat",{params: params});
    }
    
    handleError(error){
         alert(error.error);
        return throwError(error.error);
    }
}