import {Component,OnInit} from '@angular/core';
import {CustomerService} from './app.customerservice';
import {Customer} from './app.customer';
import {Address} from './app.address';
import {Book} from './app.book';
import {FormControl,FormArray,FormBuilder,FormGroup,Validators} from '@angular/forms';
import {Router} from '@angular/router';
import { error } from 'util';
@Component({
    selector:'book-app',
    templateUrl: 'app.addbook.html'
})
export class AddBook implements OnInit{
   
   book:any={};
   category:string[];
   bookForm= this.fb.group({
    name:['',Validators.required],
    author:['',Validators.required],
    publisher:['',Validators.required],
    cato:['',Validators.required],
    cid:['',Validators.required]
});
    constructor(private custservice:CustomerService,private fb:FormBuilder,private router: Router){}
    ngOnInit(){
     
        this.getCategory();
    }
    addBook(){
        this.book.name=this.bookForm.value.name;
        this.book.author=this.bookForm.value.author;
        this.book.publisher=this.bookForm.value.publisher;
        this.book.category=this.bookForm.value.cato;
        this.book.cid=this.bookForm.value.cid;
        
        this.custservice.addBook(this.book).subscribe((data:any)=>console.log(data),error);
        this.router.navigateByUrl("show");
    }
    getCategory(){
        this.custservice.getCategory().subscribe((data:any)=> this.category=data);
    };
       
}