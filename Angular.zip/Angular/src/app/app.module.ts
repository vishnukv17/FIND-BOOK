﻿import { NgModule, ErrorHandler }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import {AddCustomer} from './app.addcustomer';
import {AddBook} from './app.addbook';
import {HttpClientModule} from '@angular/common/http';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {Routes,RouterModule, Router} from '@angular/router';
import { BookDisplay } from './app.showallbooks';
import { SearchByName } from './app.searchbyname';
import { SearchBook } from './app.searchbookcat';
import { SearchByCategory } from './app.searchbycat';
import {NgxPaginationModule} from 'ngx-pagination';
import {PostCustomer} from './app.postaddcustomer';
import { CustomerService } from './app.customerservice';

const route:Routes=[
    {path:"",redirectTo:"show",pathMatch:"full"},
    {path:"postaddcust", component:PostCustomer},
    {path:"add", component:AddCustomer},
    {path:"addbook", component:AddBook},
    {path:"show", component:BookDisplay},
    {path:"namesearch", component:SearchByName},
    {path:"booksearch", component:SearchBook},
    {path:"categorysearch", component:SearchByCategory}
    ];
@NgModule({
    imports: [
        BrowserModule,
        HttpClientModule,
        FormsModule,
        RouterModule.forRoot(route),
        NgxPaginationModule,
        ReactiveFormsModule,
        
        
    ],
    declarations: [
        AppComponent,
        AddCustomer, 
        AddBook,
        BookDisplay,
        SearchByName,
        SearchBook,
        SearchByCategory,
        PostCustomer
		],
    providers: [{provide:ErrorHandler,useClass:CustomerService} ],
    bootstrap: [AppComponent]
})

export class AppModule { }