import {Address} from './app.address';
import {Book} from './app.book';
export class Customer{
    
    name:string;
    phone:number;
    email:string;
    address:Address;
    books:Book[];
}