import {Component,OnInit} from '@angular/core';
import {CustomerService} from './app.customerservice';
import {Customer} from './app.customer';
import {Address} from './app.address';
import {Book} from './app.book';
import {FormControl,FormArray,FormBuilder,FormGroup,Validators} from '@angular/forms';
@Component({
    selector:'book-app',
    templateUrl: 'app.searchbyname.html'
})
export class SearchByName implements OnInit{
    searchForm= this.fb.group({
        bookname:['',Validators.required],
       
    });
    customers:Customer[];
  
    constructor(private custservice:CustomerService,private fb:FormBuilder){}
    ngOnInit(){
        
    }
   search(){
    if(this.searchForm.value.bookname!='')
        this.custservice.searchByName(this.searchForm.value.bookname).subscribe((data:any)=>this.customers=data);

   }
       
}