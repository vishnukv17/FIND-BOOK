import {Component,OnInit} from '@angular/core';
import {CustomerService} from './app.customerservice';
import {Customer} from './app.customer';
import {Address} from './app.address';
import {Book} from './app.book';


@Component({
    selector:'cust-app',
    templateUrl: 'app.showallbooks.html'
})
export class BookDisplay implements OnInit{
   
    
    books:Book[];
   cust:any={};
    constructor(private custservice:CustomerService){}
    ngOnInit(){
        this.custservice.getAllBooks().subscribe((data:Book[])=>this.books=data);
    }
    addCustomer(){
        this.custservice.addCustomer(this.cust).subscribe((data:any)=>console.log(data));
    }
}