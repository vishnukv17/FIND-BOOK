
import {Component,OnInit, Directive} from '@angular/core';
import {CustomerService} from './app.customerservice';
import {Customer} from './app.customer';
import {Address} from './app.address';
import {Book} from './app.book';
import {FormControl,FormArray,FormBuilder,FormGroup,Validators} from '@angular/forms';

@Component({
    selector:'post-cust',
    templateUrl: 'app.postaddcustomer.html'
})


export class PostCustomer implements OnInit{
    ngOnInit(){
        
    }

}