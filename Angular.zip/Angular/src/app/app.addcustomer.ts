import {Component,OnInit, Directive} from '@angular/core';
import {CustomerService} from './app.customerservice';
import {Customer} from './app.customer';
import {Address} from './app.address';
import {Book} from './app.book';
import {FormControl,FormArray,FormBuilder,FormGroup,Validators} from '@angular/forms';
import {Router} from '@angular/router';
@Component({
    selector:'cust-app',
    templateUrl: 'app.addcustomer.html'
})

export class AddCustomer implements OnInit{
    
   customer:Customer;
   cust:any={};
   customerForm= this.fb.group({
       name:['',Validators.required],
       phone:['',[Validators.required,Validators.pattern("[0-9]{10}")]],
       email:['',[Validators.required,Validators.email]],
       address:this.fb.group({
           houseNo:['',Validators.required],
           area:['',Validators.required],
           city:['',Validators.required],
           state:['',Validators.required],
           pincode:['',[Validators.required,Validators.pattern("[0-9]{6}")]]
       })
   });
   
    constructor(private custservice:CustomerService,private fb: FormBuilder,private router: Router){}
    ngOnInit(){
        
    }
    addCustomer(){
        this.cust.name=this.customerForm.value.name;
        this.cust.phone=this.customerForm.value.phone;
        this.cust.email=this.customerForm.value.email;
        this.cust.houseNo=this.customerForm.value.address.houseNo;
        this.cust.area=this.customerForm.value.address.area;
        this.cust.city=this.customerForm.value.address.city;
        this.cust.state=this.customerForm.value.address.state;
        this.cust.pincode=this.customerForm.value.address.pincode;
        this.custservice.addCustomer(this.cust).subscribe((data:any)=>this.customer=data);
       this.router.navigateByUrl("postaddcust");
    }
}