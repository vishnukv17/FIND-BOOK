package com.cg.findbook.dao;

import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Customer;
import com.cg.findbook.util.DBUtil;
/**
 * Repository Layer Implementation. 
 * @author vishkv
 * @version 1.0
 * @since 2019-04-10 
 */
@Repository("customerRepository")
public class CustomerRepositoryImpl implements CustomerRepository{
	/* customerData and bookData are variables that are used for temporary storage of data. */
	private static final Logger LOGGER = Logger.getLogger(CustomerRepositoryImpl.class);
	List<Customer> customerData;
	List<Book> bookData;
	/**
	 * Last modified on 2019-05-02
	 * The following method is used to save a new Customer or Book to the collection. 
	 * @param customer This is the Customer object to be added or modified.
	 * @return Customer
	 */
	public Customer save(Customer customer) {
		DBUtil.customerList.add(customer);
		LOGGER.info("Added new Customer "+customer);
		return customer;
	}

	/** 
	 * Last modified on 2019-05-02
	 * The following Method is used to find the customers who have a particular category book
	 * @param category This string contains the category to be search.
	 * @return List of Customers having the book that falls in the particular category
	 */
	public List<Customer> findCustomersByCategory(String category) {
		LOGGER.info("Search using category: "+category);
		customerData=new ArrayList<Customer>();
		for (Customer customer : DBUtil.customerList) 
			if(customer.getBooks()!=null) 
				for (Book book : customer.getBooks()) 
					if(book.getCategory().toLowerCase().contains(category.toLowerCase())&& (!customerData.contains(customer))) 
						customerData.add(customer);

		LOGGER.info("Data returned: "+customerData);
		return customerData;
	}

	/** 
	 * Last modified on 2019-05-02
	 * The following Method is used to find the customers who have a particular book: It is a keyword case insensitive search
	 * @param bookName This string acts as the keyword for searching.
	 * @return List of Customers having the book with parameter bookName
	 */
	public List<Customer> findCustomersByBook(String bookName) {
		LOGGER.info("Search using book name: "+bookName);
		customerData=new ArrayList<Customer>();
		for (Customer customer : DBUtil.customerList) 
			if(customer.getBooks()!=null) 
				for (Book book : customer.getBooks()) 
					if(book.getName().toLowerCase().contains(bookName.toLowerCase())&& (!customerData.contains(customer))) 
						customerData.add(customer);
		LOGGER.info("Data returned: "+customerData);
		return customerData;
	}

	/** 
	 * Last modified on 2019-05-02
	 * The following Method is used to find the customer by Id.
	 * @param customerId This integer value is the id of customer to be searched.
	 * @return Customer having that particular id.
	 */
	public Customer findCustomerById(int customerId) {
		for (Customer customer : DBUtil.customerList) 
			if(customer.getId()==customerId) 
				return customer;
		LOGGER.warn("No data returned!");
		return null;
	}

	/** 
	 * Last modified on 2019-05-02
	 * The following Method is used to retrieve all the books.
	 * @return List of all Books 
	 */
	public List<Book> getAllBooks() {
		customerData=new ArrayList<Customer>();
		bookData=new ArrayList<Book>();
		for (Customer customers : DBUtil.customerList) 
			if(customers.getBooks()!=null) 
				for (Book book : customers.getBooks()) 
					bookData.add(book);
		LOGGER.info("Data returned: "+bookData);
		return bookData;
	}

	/** 
	 * Last modified on 2019-05-02
	 * The following Method is used to search the books that falls in a particular category.
	 * @param category This string contains the category to be search.
	 * @return List of Customers having the book that falls in the particular category
	 */
	public List<Book> findBooksByCategory(String category) {
		List<Book> bookList= new ArrayList<Book>();
		for (Book book : getAllBooks()) 
			if(book.getCategory().toLowerCase().contains(category.toLowerCase())&& (!bookList.contains(book))) 
				bookList.add(book);
		LOGGER.info("Data returned: "+bookList);
		return bookList;
	}

}
