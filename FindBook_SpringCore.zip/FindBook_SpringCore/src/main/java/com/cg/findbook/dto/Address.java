package com.cg.findbook.dto;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
/**
 * Address is a POJO that contains details of Address
 * @author vishkv
 * @version 1.0
 * @since 2019-04-10 
 */
@Component("address")
@Scope(value="prototype")
public class Address {

	private String houseNo;
	private String area;
	private String city;
	private String state;
	private long pincode;

	public Address() {

	}

	public Address(String houseNo, String area, String city, String state, long pincode) {
		super();
		this.houseNo = houseNo;
		this.area = area;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
	}
	public String getHouseNo() {
		return houseNo;
	}
	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public long getPincode() {
		return pincode;
	}
	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "" + houseNo + ", " + area + ", " + city + ", " + state + ", "
				+ pincode ;
	}

}
