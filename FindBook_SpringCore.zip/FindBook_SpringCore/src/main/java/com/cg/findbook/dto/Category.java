package com.cg.findbook.dto;
/**
 * ENUM for Category. 
 * @author vishkv
 * @version 1.0
 * @since 2019-04-20 
 */
public enum Category {
FICTION,CLASSICS,EDUCATION,JOURNALS,SCIENCE;
}
