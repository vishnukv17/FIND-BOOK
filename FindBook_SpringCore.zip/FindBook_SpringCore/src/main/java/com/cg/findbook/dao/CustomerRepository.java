package com.cg.findbook.dao;

import java.util.List;
import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Customer;
/**
 * Repository Interface. 
 * @author vishkv
 * @version 1.0
 * @since 2019-04-10 
 */
public interface CustomerRepository {
	
	Customer save(Customer customer);
	List<Customer> findCustomersByCategory(String category);
	List<Customer> findCustomersByBook(String bookName);
	Customer findCustomerById(int id);
	List<Book> getAllBooks();
	List<Book> findBooksByCategory(String category);

}
