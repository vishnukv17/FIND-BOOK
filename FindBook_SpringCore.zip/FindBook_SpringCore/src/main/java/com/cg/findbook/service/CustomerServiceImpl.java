package com.cg.findbook.service;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.findbook.dao.CustomerRepository;
import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Category;
import com.cg.findbook.dto.Customer;
import com.cg.findbook.exceptions.BookDetailNotFoundException;
import com.cg.findbook.exceptions.CustomerDetailNotFoundException;
/**
 * Service Layer Implementation. 
 * @author vishkv
 * @version 1.0
 * @since 2019-04-10 
 */
@Service("customerService")
public class CustomerServiceImpl implements CustomerService{
	private static final Logger LOGGER = Logger.getLogger(CustomerServiceImpl.class);
	@Autowired
	private CustomerRepository  customerRepository;
	/*
	 * The static variables customerCount and bookCount are used to generate ID for respected entities. These are initialized 
	 * to a particular value. 
	 */
	private static int customerCount=100;
	private static int bookCount=1000;
	public  CustomerServiceImpl() {
	}

	/**
	 * Last modified on 2019-05-02
	 * @author vishkv
	 * The following method is used to add a new Customer 
	 * @param customer This is the Customer to be added
	 * @return Customer
	 */
	public Customer add(Customer customer) {
		customerCount++;
		customer.setId(customerCount);
		return customerRepository.save(customer);
	}

	/**
	 * Last modified on 2019-05-02
	 * The assignBookToCustomer() Method is used to add a new Book and assign that book to the mentioned customer 
	 * @author vishkv
	 * @param book This is the book to be added
	 * @param customerId This is the id of the Customer to whom the book must be added
	 * @return Customer
	 * @exception CustomerDetailNotFoundException  thrown when details of Customer is not found.
	 * */
	public Customer assignBookToCustomer(Book book, int customerId) throws CustomerDetailNotFoundException {
		List<Book> bookList;
		Customer customer=customerRepository.findCustomerById(customerId);
		if(customer!=null) {
			LOGGER.info("Before adding  book:  "+customer);
			bookCount++;
			if(customer.getBooks()!=null) 
				bookList=customer.getBooks();
			else
				bookList=new ArrayList<Book>();
			book.setId(bookCount);
			bookList.add(book);

			customer.setBooks(bookList);
			LOGGER.info("After adding  book:  "+customer);
			return customer;
		}
		throw new CustomerDetailNotFoundException("Id not found!");
	}

	/** 
	 * Last modified on 2019-05-02
	 * The following Method is used to search the customers who have a particular book: It is a keyword search
	 * @author vishkv
	 * @param bookName This string acts as the keyword for searching.
	 * @return List of Customers having the book with parameter bookName
	 * @exception CustomerDetailNotFoundException  thrown when details of Customer is not found.
	 * @see {@link CustomerDetailNotFoundException}  
	 */
	public List<Customer> searchCustomersByBookName(String bookName) throws CustomerDetailNotFoundException {
		if(customerRepository.findCustomersByBook(bookName).isEmpty())
			throw new CustomerDetailNotFoundException("No match found!");
		return customerRepository.findCustomersByBook(bookName);
	}

	/** 
	 * Last modified on 2019-05-02
	 * The following Method is used to search the customers who have a particular category book
	 * @author vishkv
	 * @param category This string contains the category to be search.
	 * @return List of Customers having the book that falls in the particular category
	 * @exception CustomerDetailNotFoundException thrown when details of Customer is not found.
	 * @see {@link CustomerDetailNotFoundException}  
	 */
	public List<Customer> searchCustomersByCategory(String category) throws CustomerDetailNotFoundException {

		if(customerRepository.findCustomersByCategory(category).isEmpty())
			throw new CustomerDetailNotFoundException("No match found!");
		return customerRepository.findCustomersByCategory(category);

	}

	/** 
	 * Last modified on 2019-05-02
	 * The following Method is used to search the books that falls in a particular category.
	 * @author vishkv
	 * @param category This string contains the category to be search.
	 * @return List of Customers having the book that falls in the particular category
	 * @exception BookDetailNotFoundException thrown when details of Book is not found.
	 * @see {@link BookDetailNotFoundException}  
	 */
	public List<Book> searchBooksByCategory(String category) throws BookDetailNotFoundException {
		if(customerRepository.findBooksByCategory(category).isEmpty())
			throw new BookDetailNotFoundException("No books found in this category!");
		return customerRepository.findBooksByCategory(category);
	}

	/** 
	 * Last modified on 2019-05-02
	 * The following Method is used to retrieve all the books.
	 * @author vishkv
	 * @return List of all Books 
	 * @exception BookDetailNotFoundException
	 * @see {@link BookDetailNotFoundException}  
	 */
	public List<Book> getAllBooks() throws BookDetailNotFoundException {

		if(customerRepository.getAllBooks().isEmpty())
			throw new BookDetailNotFoundException("No books found!");
		return(customerRepository.getAllBooks());
	}

	/** 
	 * Last modified on 2019-05-02
	 * The following Method is used to select a category from available category.
	 * @author vishkv
	 * @return String The category.  
	 * @param choiceCategory integer :The choice made by the user
	 */
	public String selectCategory(int choiceCategory) {
		String category=null;
		switch(choiceCategory) {
		case 1: category=Category.FICTION.toString();
		break;
		case 2: category=Category.CLASSICS.toString();
		break;
		case 3: category=Category.EDUCATION.toString();
		break;
		case 4: category=Category.JOURNALS.toString();
		break;
		case 5: category=Category.SCIENCE.toString();
		break;
		}
		LOGGER.info("Category returned:  "+category);
		return category;
	}

}
