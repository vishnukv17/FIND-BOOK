package com.cg.findbook.util;
import com.cg.findbook.dto.*;
import java.util.ArrayList;
import java.util.List;
/**
 * The class that has the static List that stores all data that is being added!  
 * @author vishkv
 * @version 1.0
 * @since 2019-04-20 
 */
public class DBUtil {
	public static List<Customer> customerList= new ArrayList<Customer>();
	
}
