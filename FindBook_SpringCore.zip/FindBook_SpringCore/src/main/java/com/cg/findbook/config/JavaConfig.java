package com.cg.findbook.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
/**
 * Java configuration class. Used for Spring Container creation.
 * @author vishkv
 * @version 1.0
 * @since 2019-05-14 
 */

@Configuration
@ComponentScan("com.cg.findbook")
public class JavaConfig {

}
