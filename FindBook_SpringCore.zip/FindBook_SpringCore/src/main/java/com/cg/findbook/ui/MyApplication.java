package com.cg.findbook.ui;
import java.math.BigInteger;
import java.util.Scanner;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;
import com.cg.findbook.config.JavaConfig;
import com.cg.findbook.dto.Address;
import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Category;
import com.cg.findbook.dto.Customer;
import com.cg.findbook.exceptions.BookDetailNotFoundException;
import com.cg.findbook.exceptions.CustomerDetailNotFoundException;
import com.cg.findbook.service.CustomerService;
/** 
 * UI of the Application. Currently, console input outputs are done here 
 * @author vishkv
 * @version 1.0
 * @since 2019-04-10
 */
@Component
public class MyApplication {
	static Scanner sc=new Scanner(System.in);
	private static CustomerService customerService;
	@Autowired
	private CustomerService service;
	@PostConstruct
	private void init() {
		customerService=service;
	}
	public static void main(String[] args) {
		ApplicationContext app= new AnnotationConfigApplicationContext(JavaConfig.class);

		String bookName=null;
		String category=null;
		int choice=0;
		do {

			print();
			choice=sc.nextInt();
			switch(choice) {
			case 1: 
				/* Add new Customer */
				sc.nextLine();
				System.out.println("Enter  Name: ");
				String name=sc.nextLine();
				System.out.println("Enter Email: ");
				String email=sc.nextLine();
				System.out.println("Enter Phone: ");
				String phone=sc.nextLine();
				System.out.println("Enter  House No: ");
				String houseNumber=sc.nextLine();
				System.out.println("Enter Area: ");
				String area=sc.nextLine();
				System.out.println("Enter City: ");
				String city=sc.nextLine();
				System.out.println("Enter State: ");
				String state=sc.nextLine();
				System.out.println("Enter Pincode: ");
				long pincode=sc.nextLong();
				Customer customer=app.getBean(Customer.class);	
				Address address=app.getBean(Address.class);
				customer.setName(name);
				customer.setPhone(new BigInteger(phone));
				customer.setEmail(email);
				address.setArea(area);
				address.setCity(city);
				address.setPincode(pincode);
				address.setState(state);
				address.setHouseNo(houseNumber);
				customer.setAddress(address);
				customer=customerService.add(customer);
				System.out.println("Details added! Your ID is "+customer.getId());
				break;
			case 2: 
				/* Add new Book and assign to customer */
				sc.nextLine();
				System.out.println("Enter Book Name: ");
				String bName=sc.nextLine();
				category=readCategory();
				sc.nextLine();
				System.out.println("Enter  Author: ");
				String author=sc.nextLine();
				System.out.println("Enter  Publisher: ");
				String publisher=sc.nextLine();
				System.out.println("Enter customer id: ");
				int custId=sc.nextInt();
				Book book=app.getBean(Book.class);
				book.setName(bName);
				book.setAuthor(author);
				book.setCategory(category);
				book.setPublisher(publisher);
				try {
					customerService.assignBookToCustomer(book,custId);
					System.out.println("Book added successfully!");
				} catch (CustomerDetailNotFoundException e) { 
					System.out.println(e.getMessage());
				}
				break;
			case 3: 
				/* Retrieve All books */
				try {
					for (Book bookTwo : customerService.getAllBooks()) 
						System.out.println(bookTwo);
				} catch (BookDetailNotFoundException e1) {
					System.out.println(e1.getMessage());
				}
				break;
			case 4: 
				/*Search Customers by book name */
				sc.nextLine();
				System.out.println("Enter the Book name: ");
				bookName=sc.nextLine();
				try {
					for (Customer customerTwo : customerService.searchCustomersByBookName(bookName)) 
						System.out.println(customerTwo);
				} catch (CustomerDetailNotFoundException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 5: 
				/* Search Customers by category */
				sc.nextLine();
				category=readCategory();
				try {
					for (Customer customerTwo : customerService.searchCustomersByCategory(category)) 
						System.out.println(customerTwo);
				} catch (CustomerDetailNotFoundException e) {
					System.out.println(e.getMessage());
				}

				break;
			case 6:
				/* Search books by category */
				sc.nextLine();
				System.out.println("Enter the Book Category: ");
				category=readCategory();
				try {
					for (Book bookTwo : customerService.searchBooksByCategory(category)) 
						System.out.println(bookTwo);
				} catch (BookDetailNotFoundException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 7: break;

			default: System.out.println("Wrong choice");
			}
		}while(choice!=7);
		sc.close();
		((ConfigurableApplicationContext)app).close();
	}	
	/**
	 *  Method prints the menu. 
	 *  Last modified on 2019-04-20
	 *  @return void
	 */
	static void print() {
		System.out.println("1. Add new Customer");
		System.out.println("2. Add new Book ");
		System.out.println("3. View All Books");
		System.out.println("4. Search Book Owners by book name ");
		System.out.println("5. Search Book Owners by category");
		System.out.println("6. Search Books by category");
		System.out.println("7. Exit");
	}

	/**
	 *  Method prints the Categories and asks the user to select one among them. 
	 *  Last Modified on 2019-04-24
	 *  @return String : the category selected.
	 */
	static String readCategory() {
		int i=1;
		String category=null;
		for (Category cat : Category.values()) {
			System.out.println(i+". "+cat);
			i++;
		}
		System.out.println("Select  Category: ");
		int choiceCategory=sc.nextInt();
		category=customerService.selectCategory(choiceCategory);
		return category;

	}
}
