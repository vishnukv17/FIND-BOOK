package com.cg.findbook.config;
/**
 * WebMvc class is used for View Resolving
 * @author vishkv
 * @version 1.0
 * @since 2019-05-20 
 */
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;
@Configuration
@EnableWebMvc
@ComponentScan("com.cg.findbook")
public class WebMvc implements WebMvcConfigurer{

	/**
	 * Last modified on 2019-05-20
	 * @author vishkv
	 * The following method is return the ViewResolver
	 * Sets prefix and suffix to the views
	 * @return InternalResourceViewResolver viewResolver
	 */
	@Bean
	public InternalResourceViewResolver getAllView() {
		InternalResourceViewResolver viewResolver=new InternalResourceViewResolver();
		viewResolver.setViewClass(JstlView.class);
		viewResolver.setPrefix("/WEB-INF/pages/");
		viewResolver.setSuffix(".jsp");
		
		return viewResolver;
	}
}
