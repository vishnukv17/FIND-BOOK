package com.cg.findbook.config;

import java.util.Properties;

import javax.sql.DataSource;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;

import org.springframework.transaction.annotation.EnableTransactionManagement;
/**
 * AppContext class is used for bean-package scan, set connection configurations 
 * @author vishkv
 * @version 1.0
 * @since 2019-05-20 
 */
@Configuration
@EnableTransactionManagement
@PropertySource("classpath:resources/jdbc.properties")
@ComponentScan("com.cg.findbook")
public class AppContext {
	@Autowired
	private Environment environment;

	/**
	 * Last modified on 2019-05-20
	 * @author vishkv
	 * The following method is scan the package and return the sessionFactory 
	 * @return sessionFactory
	 */
	@Bean
	public LocalSessionFactoryBean sessionFactory() {
		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(dataSource());
		sessionFactory.setPackagesToScan(new String[] { "com.cg.findbook.dto" });
		sessionFactory.setHibernateProperties(hibernateProperties());
		return sessionFactory;
	}

	/**
	 * Last modified on 2019-05-20
	 * @author vishkv
	 * The following method is to connect with mysql database
	 * @return DataSource
	 */
	@Bean
	public DataSource dataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(environment.getRequiredProperty("jdbc.driver"));
		dataSource.setUrl(environment.getRequiredProperty("jdbc.url"));
		dataSource.setUsername(environment.getRequiredProperty("jdbc.username"));
		dataSource.setPassword(environment.getRequiredProperty("jdbc.password"));
		return dataSource;
	}

	/**
	 * Last modified on 2019-05-20
	 * @author vishkv
	 * The following method is to get the Hibernate Properties
	 * @return Properties
	 */
	private Properties hibernateProperties() {
		Properties properties = new Properties();
		properties.put("hibernate.dialect", environment.getRequiredProperty("jdbc.dialect"));
		properties.put("hibernate.hbm2ddl.auto", environment.getRequiredProperty("jdbc.auto"));
		properties.put("hibernate.sql+format",true);
		return properties;
	}

	/**
	 * Last modified on 2019-05-20
	 * @author vishkv
	 * The following method is to get the TransactionManager
	 * @return HibernateTransactionManager
	 */
	@Bean
	public HibernateTransactionManager getTransactionManager() {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager();
		transactionManager.setSessionFactory(sessionFactory().getObject());
		return transactionManager;
	}
	

}
