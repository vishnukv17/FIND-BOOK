package com.cg.findbook.config;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

/**
 * ApplicationInitializer class is used for managing the all the Mappings and Configurations
 * @author vishkv
 * @version 1.0
 * @since 2019-05-20 
 */
public class ApplicationInitializer extends AbstractAnnotationConfigDispatcherServletInitializer{

	/**
	 * Last modified on 2019-05-20
	 * @author vishkv
	 * The following method is return the congifuration class
	 * @return Class[] : AppContext.class
	 */
	@Override
	protected Class<?>[] getRootConfigClasses() {
		
		return new Class[] {AppContext.class};
	}

	/**
	 * Last modified on 2019-05-20
	 * @author vishkv
	 * The following method is return the ViewResolver class
	 * @return Class[] : WebMvc.class
	 */
	@Override
	protected Class<?>[] getServletConfigClasses() {
		
		return new Class[] {WebMvc.class};
	}

	/**
	 * Last modified on 2019-05-20
	 * @author vishkv
	 * The following method is return the Mapping pattern(url patterns) attached before the name of the action
	 * @return String[] : the pattern
	 */
	@Override
	protected String[] getServletMappings() {
		
		return new String[] {"/"};
	}

}
