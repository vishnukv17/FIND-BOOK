/** @author vishkv
 * CustomerDetailNotFoundException is raised when user searches for customer(s) and no match is found.
 * dated: 2019-04-15
 */
package com.cg.findbook.exceptions;
/**
 * The CustomerDetailNotFoundException is thrown whenever a search for a customer is performed and no data is found.
 * You can use this code to retrieve localized error messages.
 *  @author vishkv
 * @version 1.0
 * @since 2019-04-20 
 */
@SuppressWarnings("serial")
public class CustomerDetailNotFoundException extends Exception {
	
	public CustomerDetailNotFoundException() {
		super();
	}
	public CustomerDetailNotFoundException(String exceptionMessage) {
		super(exceptionMessage);
	}
	

}
