package com.cg.findbook.dao;
/**
 * Query Interface. 
 * @author vishkv
 * @version 1.0
 * @since 2019-04-10
 * Contains all the JPQL queries that are used. 
 */
public interface DBQueries {
		
		public static final String selectAllBooks="select book from Book book";
		public static final String selectBooksByCategory="select book from Book book where book.category=?1";
		public static final String selectCustomerByBook="select distinct customer FROM Customer customer, IN(customer.books) book WHERE book.name like ?1";
		public static final String selectCustomerByCategory="select distinct customer FROM Customer customer, IN(customer.books) book WHERE book.category=?1";
}
