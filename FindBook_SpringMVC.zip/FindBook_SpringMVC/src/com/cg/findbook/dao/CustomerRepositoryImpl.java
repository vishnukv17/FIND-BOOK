package com.cg.findbook.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Customer;
import com.cg.findbook.exceptions.CustomerDetailNotFoundException;
/**
 * Repository Layer Implementation. 
 * @author vishkv
 * @version 1.0
 * @since 2019-04-10 
 */
@Repository("customerRepository")

public class CustomerRepositoryImpl implements CustomerRepository{
	
	@PersistenceContext
	EntityManager entitymanager;
	private static final Logger LOGGER = Logger.getLogger(CustomerRepositoryImpl.class);
	/* 
 	Last modified on 2019-05-03
  	The save() Method is used to save customer and book to the database */

	/**
	 * @author vishkv
	 * Last modified on 2019-05-02
	 * The following method is used to save a new Customer to the database. 
	 * @param customer This is the Customer object to be added.
	 * @return Customer
	 */
	public Customer save(Customer customer)  {
		if((entitymanager.find(Customer.class, customer.getId())==null)) {
			entitymanager.persist(customer);
			entitymanager.flush();
			LOGGER.info("Customer data added:"+customer);
			return customer;
		}
		LOGGER.warn("Data not added!");
		return null;

	}
	
	/**
	 * @author vishkv
	 * Last modified on 2019-05-18
	 * The following method is used to save a new Book to the database. 
	 * @param customer This is the Book object to be added.
	 * @return Customer
	 */
	@Override
	public Customer saveBook(Book book) {
		entitymanager.persist(book);
		entitymanager.flush();
		LOGGER.info("Book data added:"+book);
		return book.getCustomer();
	}


	/** 
	 * @author vishkv
 	 * Last modified on 2019-05-02
	 * The following Method is used to find the customers who have a particular category book
	 * @param category This string contains the category to be search.
	 * @return List of Customers having the book that falls in the particular category
	 */
	public List<Customer> findCustomersByCategory(String category) {


		TypedQuery<Customer> query=entitymanager.createQuery(DBQueries.selectCustomerByCategory,Customer.class);
		query.setParameter(1,category);
		try {
		List<Customer> customers=query.getResultList();
		LOGGER.info("Customer data returned:"+customers);
		return customers;
		}catch (NoResultException e) {
			LOGGER.info("No results!"+e.getMessage());
			return null;
		}

	}

	/** 
	 * @author vishkv
	 * Last modified on 2019-05-02
	 * The following Method is used to find the customers who have a particular book: It is a keyword case insensitive search
	 * @param bookName This string acts as the keyword for searching.
	 * @return List of Customers having the book with parameter bookName
	 */
	public List<Customer> findCustomersByBook(String bookName)  {


		TypedQuery<Customer> query=entitymanager.createQuery(DBQueries.selectCustomerByBook,Customer.class);
		query.setParameter(1,"%"+bookName+"%");
		try {
		List<Customer> customers=query.getResultList();
		LOGGER.info("Customer data returned:"+customers);
		return customers;
		}catch (NoResultException e) {
			LOGGER.info("No results!"+e.getMessage());
			return null;
		}

	}

	/** 
	 * @author vishkv
	 * Last modified on 2019-05-02
	 * The following Method is used to find the customer by Id.
	 * @param customerId This integer value is the id of customer to be searched.
	 * @return Customer having that particular id.
	 */
	public Customer findCustomerById(int customerId) throws CustomerDetailNotFoundException {
		Customer customer=entitymanager.find(Customer.class,customerId);
		if(customer!=null) {
			LOGGER.info("Customer returned:"+customer);
			return customer;
		}
		else {
			return null;
		}

	}

	/** 
	 * @author vishkv
	 * Last modified on 2019-05-02
	 * The following Method is used to retrieve all the books.
	 * @return List of all Books 
	 */
	public List<Book> getAllBooks()  {


		TypedQuery<Book> query=entitymanager.createQuery(DBQueries.selectAllBooks,Book.class);
		try {
		List<Book> bookData=query.getResultList();
		LOGGER.info("Book data returned:"+bookData);
		return bookData;
		}catch (NoResultException e) {
			LOGGER.info("No results!"+e.getMessage());
			return null;
		}

	}

	/** 
	 * @author vishkv
	 * Last modified on 2019-05-02
	 * The following Method is used to search the books that falls in a particular category.
	 * @param category This string contains the category to be search.
	 * @return List of Customers having the book that falls in the particular category
	 */
	public List<Book> findBooksByCategory(String category)  {

		TypedQuery<Book> query=entitymanager.createQuery(DBQueries.selectBooksByCategory,Book.class);
		query.setParameter(1,category);
		try {
		List<Book> bookData=query.getResultList();
		LOGGER.info("Book data returned:"+bookData);
		return bookData;
		}catch (NoResultException e) {
			LOGGER.info("No results!"+e.getMessage());
			return null;
		}

	}


}
