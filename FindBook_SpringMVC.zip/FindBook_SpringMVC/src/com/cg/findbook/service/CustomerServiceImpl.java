package com.cg.findbook.service;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.findbook.dao.CustomerRepository;
import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Customer;
import com.cg.findbook.exceptions.BookDetailNotFoundException;
import com.cg.findbook.exceptions.CustomerDetailNotFoundException;

/**
 * Service Layer Implementation. 
 * @author vishkv
 * @version 1.0
 * @since 2019-04-10 
 */
@Service("customerService")
@Transactional
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	private CustomerRepository  customerRepository;

	private static final Logger LOGGER = Logger.getLogger(CustomerServiceImpl.class);
	/*
	 * The static variables customerCount and bookCount are used to generate ID for respected entities. These are initialized 
	 * to a particular value. 
	 */

	private static int bookCount=1210;
	private static int customerCount=1021;
	private static int addressCount=11021;

	public  CustomerServiceImpl() {

	}
	/**
	 * Last modified on 2019-05-02
	 * @author vishkv
	 * The following method is used to add a new Customer 
	 * @param customer This is the Customer to be added
	 * @return Customer
	 */
	public Customer add(Customer customer)  {
		customer.getAddress().setId(addressCount);
		addressCount++;
		customer.setId(customerCount);
		customerCount++;
		LOGGER.info("Sending data to repository: "+customer);
		customer=customerRepository.save(customer);
		return customer;

	}

	/**
	 * Last modified on 2019-05-02
	 * The assignBookToCustomer() Method is used to add a new Book and assign that book to the mentioned customer 
	 * @author vishkv
	 * @param book This is the book to be added
	 * @param customerId This is the id of the Customer to whom the book must be added
	 * @return Customer
	 * @exception CustomerDetailNotFoundException  thrown when details of Customer is not found.
	 * */
	public Customer assignBookToCustomer(Book book, int customerId) throws CustomerDetailNotFoundException {

		Customer customer=customerRepository.findCustomerById(customerId);
		book.setId(bookCount);
		bookCount++;
		book.setCustomer(customer);
		LOGGER.info("Sending data to repository: "+book);
		return customerRepository.saveBook(book);


	}

	/** 
	 * Last modified on 2019-05-02
	 * The following Method is used to search the customers who have a particular book: It is a keyword search
	 * @author vishkv
	 * @param bookName This string acts as the keyword for searching.
	 * @return List of Customers having the book with parameter bookName
	 * @exception CustomerDetailNotFoundException  thrown when details of Customer is not found.
	 * @see {@link CustomerDetailNotFoundException}  
	 */
	public List<Customer> searchCustomersByBookName(String bookName) throws CustomerDetailNotFoundException {
		List<Customer> customers= customerRepository.findCustomersByBook(bookName);
		if(!customers.isEmpty())
			return customers;
		else
			throw new CustomerDetailNotFoundException("No Readers found!!!");
	}

	/** 
	 * Last modified on 2019-05-02
	 * The following Method is used to search the customers who have a particular category book
	 * @author vishkv
	 * @param category This string contains the category to be search.
	 * @return List of Customers having the book that falls in the particular category
	 * @exception CustomerDetailNotFoundException thrown when details of Customer is not found.
	 * @see {@link CustomerDetailNotFoundException}  
	 */
	public List<Customer> searchCustomersByCategory(String category) throws CustomerDetailNotFoundException  {

		List<Customer> customers= customerRepository.findCustomersByCategory(category);
		if(!customers.isEmpty())
			return customers;
		else
			throw new CustomerDetailNotFoundException("No Readers found!!!");
	}

	/** 
	 * Last modified on 2019-05-02
	 * The following Method is used to search the books that falls in a particular category.
	 * @author vishkv
	 * @param category This string contains the category to be search.
	 * @return List of Customers having the book that falls in the particular category
	 * @exception BookDetailNotFoundException thrown when details of Book is not found.
	 * @see {@link BookDetailNotFoundException}  
	 */
	public List<Book> searchBooksByCategory(String category) throws BookDetailNotFoundException  {
		List<Book> books= customerRepository.findBooksByCategory(category);
		if(!books.isEmpty())
			return books;
		else
			throw new BookDetailNotFoundException("No Books found!!!");
	}

	/** 
	 * Last modified on 2019-05-02
	 * The following Method is used to retrieve all the books.
	 * @author vishkv
	 * @return List of all Books 
	 * @exception BookDetailNotFoundException
	 * @see {@link BookDetailNotFoundException}  
	 */
	public List<Book> getAllBooks() throws BookDetailNotFoundException  {
		List<Book> books= customerRepository.getAllBooks();
		if(!books.isEmpty())
			return books;
		else
			throw new BookDetailNotFoundException("No Books found!!!");
	}
	@Override
	public Customer searchById(int id) throws CustomerDetailNotFoundException {
		Customer customer= customerRepository.findCustomerById(id);
		if(customer!=null)
			return customer;
		else
			throw new CustomerDetailNotFoundException("Customer not Found");
	}

}
