package com.cg.findbook.dto;


import java.math.BigInteger;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * Customer is a POJO that contains details of Customer
 * @author vishkv
 * @version 1.0
 * @since 2019-04-10 
 */
@Entity
public class Customer {
	@Id
	private Integer id;
	private String name;
	private String email;
	private BigInteger phone;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="address_id",unique=true)
	private Address address;
	@OneToMany(cascade = CascadeType.ALL,orphanRemoval=true, mappedBy="customer",fetch=FetchType.EAGER)
	private List<Book> books;
	public Customer() {
	}
	public Customer(String name, String email, BigInteger phone, Address address, List<Book> books) {
		super();
		this.name = name;
		this.email = email;
		this.phone = phone;
		this.address = address;
		this.books = books;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id=id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public BigInteger getPhone() {
		return phone;
	}
	public void setPhone(BigInteger phone) {
		this.phone = phone;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public List<Book> getBooks() {
		return books;
	}
	public void setBooks(List<Book> books) {
		
		this.books = books;
	}
	
	@Override
	public String toString() {
		return "Customer: \n id=" + id + "\n name=" + name + ",\n email=" + email + ",\n phone=" + phone + ",\n address="
				+ address + ",\n books=" + books ;
	}

}
