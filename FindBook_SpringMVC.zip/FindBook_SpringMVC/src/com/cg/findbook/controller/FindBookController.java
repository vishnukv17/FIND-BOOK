package com.cg.findbook.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.findbook.dao.CustomerRepositoryImpl;
import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Category;
import com.cg.findbook.dto.Customer;
import com.cg.findbook.exceptions.BookDetailNotFoundException;
import com.cg.findbook.exceptions.CustomerDetailNotFoundException;
import com.cg.findbook.service.CustomerService;
import com.cg.findbook.validator.FormValidation;

/**
 * Controller Implementation. 
 * @author vishkv
 * @version 1.0
 * @since 2019-04-17 
 */
@Controller
public class FindBookController {
	private static final Logger LOGGER = Logger.getLogger(FindBookController.class);
	@Autowired
	CustomerService customerService;
	
	/**
	 * Last modified on 2019-05-18
	 * @author vishkv
	 * The following method is used to redirect to home page
	 * @return String: The name of the page to redirect
	 */
	@GetMapping(value="home")
	public String goHome() {
		return "listpage";
	}
	
	/**
	 * Last modified on 2019-05-18
	 * @author vishkv
	 * The following method is used to redirect to add customer page
	 * @param ModelAtribute: Customer
	 * @return ModelAndView: The name of the page to redirect
	 */
	@GetMapping(value="custadd")
	public ModelAndView preAddCustomer(@ModelAttribute("cust") Customer customer) {
		return new ModelAndView("addcustomer");
	}
	/**
	 * Last modified on 2019-05-18
	 * @author vishkv
	 * The following method is used to add customer 
	 * @param ModelAtribute: Customer
	 * @return ModelAndView: The name of the page to redirect(view) and the Model Customer
	 */
	@PostMapping("addcust")
	public ModelAndView addCustomer(  @ModelAttribute("cust") Customer customer,BindingResult result ) {
		FormValidation formValidation = new FormValidation();    
	    
		  formValidation.validate(customer, result);
		if(result.hasErrors()) 
			return new ModelAndView("addcustomer");
		customer=customerService.add(customer);
		return new ModelAndView("customerdetails","cust",customer);
	}
	
	/**
	 * Last modified on 2019-05-18
	 * @author vishkv
	 * The following method is used to redirect to add book page
	 * @param ModelAtribute: Customer
	 * @return ModelAndView: The name of the page to redirect
	 */
	@GetMapping("bookadd")
	public ModelAndView preAddBook(@ModelAttribute("cust") Customer customer) {
		return new ModelAndView("customercheck","check",0);
	}
	
	/**
	 * Last modified on 2019-05-18
	 * @author vishkv
	 * The following method is used to find the customer and return his details to add book page
	 * @param ModelAtribute: Customer,ModelAtribute:Book
	 * @return ModelAndView: The name of the page to redirect(View) and Model Customer
	 */
	@PostMapping(value="checkcust")
	public ModelAndView addBook(@ModelAttribute("cust") Customer customer,@ModelAttribute("book") Book book) throws CustomerDetailNotFoundException {
		customer=customerService.searchById(customer.getId()); 
		if(customer!=null) {
		List<String> categoryList=new ArrayList<>();
		for (Category category : Category.values()) {
			categoryList.add(category.toString());
		}
		Map<String,Object> addMap=new HashMap<>();
		addMap.put("cat", categoryList);
		addMap.put("cust",customer);
		return new ModelAndView("add","details",addMap);
		}
		else
			return new ModelAndView("customercheck","check",1);
	} 
	
	/**
	 * Last modified on 2019-05-18
	 * @author vishkv
	 * The following method is used to add book 
	 * @param ModelAtribute: Book, RequestParam Integer: Id of customer
	 * @return ModelAndView: The name of the page to redirect(view) and the Model Customer
	 */
	@PostMapping(value="addbk")
	public ModelAndView postAddBook(@ModelAttribute("book") Book book, @RequestParam("cid") Integer id) throws CustomerDetailNotFoundException {
		
		Customer customer=customerService.assignBookToCustomer(book, id);
		return new ModelAndView("success","customer",customer);
	}
	
	/**
	 * Last modified on 2019-05-18
	 * @author vishkv
	 * The following method is used to redirect to show all page 
	 * @return ModelAndView: The name of the page to redirect(view) and the Model List<Book>
	 * @exception BookDetailNotFoundException thrown when details of Book is not found.
	 */
	@GetMapping("showbks")
	public ModelAndView showAllBooks() throws BookDetailNotFoundException {
		List<Book> books=customerService.getAllBooks();
		return new ModelAndView("showall","books", books);
	}
	
	/**
	 * Last modified on 2019-05-18
	 * @author vishkv
	 * The following method is used to redirect to search page 
	 * @param ModelAtribute: Customer
	 * @return ModelAndView: The name of the page to redirect(view) 
	 */
	@GetMapping("srchbname")
	public ModelAndView preSearchByBook(@ModelAttribute("cust") Customer customer) {
		return new ModelAndView("byname","check",0);
	}
	
	/**
	 * Last modified on 2019-05-18
	 * @author vishkv
	 * The following method is used to search Customers by book name 
	 * @param ModelAtribute: Customer
	 * @return ModelAndView: The name of the page to redirect(view) 
	 * @exception CustomerDetailNotFoundException  thrown when details of Customer is not found.
	 */
	@PostMapping("srchbook")
	public ModelAndView searchByBookName(@RequestParam("bookname") String bookName ) throws CustomerDetailNotFoundException {
		List<Customer> customers=customerService.searchCustomersByBookName(bookName);
		Map<String,Object> searchMap=new HashMap<String, Object>();
		searchMap.put("custs", customers);
		return new ModelAndView("byname","details", searchMap);
	}
	
	/**
	 * Last modified on 2019-05-18
	 * @author vishkv
	 * The following method is used to redirect to search by category page 
	 * @param ModelAtribute: Book
	 * @return ModelAndView: The name of the page to redirect(view) 
	 */
	@GetMapping("custcat")
	public ModelAndView preSearchCat(@ModelAttribute("book") Book book) {
		List<String> categoryList=new ArrayList<>();
		for (Category category : Category.values()) {
			categoryList.add(category.toString());
		}
		Map<String,Object> searchMap=new HashMap<>();
		searchMap.put("cat", categoryList);
		searchMap.put("check",0);
		return new ModelAndView("bycat","details",searchMap);
	}
	
	/**
	 * Last modified on 2019-05-18
	 * @author vishkv
	 * The following method is used to search Customers by book category 
	 * @param ModelAtribute: Book
	 * @return ModelAndView: Map containing category and List<Customers>
	 * @exception CustomerDetailNotFoundException  thrown when details of Customer is not found.
	 */
	@PostMapping("srchcat")
	public ModelAndView searchByBookCat(@ModelAttribute("book") Book book ) throws CustomerDetailNotFoundException {
		List<Customer> customers=customerService.searchCustomersByCategory(book.getCategory());
		List<String> categoryList=new ArrayList<>();
		for (Category category : Category.values()) {
			categoryList.add(category.toString());
		}
		Map<String,Object> searchMap=new HashMap<>();
		searchMap.put("cat", categoryList);
		searchMap.put("custs", customers);
		return new ModelAndView("bycat","details", searchMap);
	}
	
	/**
	 * Last modified on 2019-05-18
	 * @author vishkv
	 * The following method is used to redircect search Books by book category page
	 * @param ModelAtribute: Book
	 * @return ModelAndView: Category List
	 */
	@GetMapping("bookcat")
	public ModelAndView preSearchBCat(@ModelAttribute("book") Book book) {
		List<String> categoryList=new ArrayList<>();
		for (Category category : Category.values()) {
			categoryList.add(category.toString());
		}
		Map<String,Object> searchMap=new HashMap<>();
		searchMap.put("cat", categoryList);
		searchMap.put("check",0);
		return new ModelAndView("bybcat","details",searchMap);
	}
	
	/**
	 * Last modified on 2019-05-18
	 * @author vishkv
	 * The following method is used to search Books by book category 
	 * @param ModelAtribute: Book
	 * @return ModelAndView: Map containing category and List<Customers>
	 * @exception BookDetailNotFoundException thrown when details of Book is not found.
	 */
	@PostMapping("srchbcat")
	public ModelAndView searchBookByCat(@ModelAttribute("book") Book book ) throws BookDetailNotFoundException {
		List<Book> books=customerService.searchBooksByCategory(book.getCategory());
		List<String> categoryList=new ArrayList<>();
		for (Category category : Category.values()) {
			categoryList.add(category.toString());
		}
		Map<String,Object> searchMap=new HashMap<>();
		searchMap.put("cat", categoryList);
		searchMap.put("books", books);
		return new ModelAndView("bybcat","details", searchMap);
	}
	
	/**
	 * Last modified on 2019-05-22
	 * @author vishkv
	 * The following method is used to handle CustomerDetailNotFoundException
	 * @return ModelAndView: To No data found page(View) Model- String: Message
	 */
	@ExceptionHandler(CustomerDetailNotFoundException.class)
	public ModelAndView handleCustomerDetailNotFoundException() {
		LOGGER.error("Resolved"+CustomerDetailNotFoundException.class.getName());
		return new ModelAndView("nodatafound","message","Reader");
	}
	
	/**
	 * Last modified on 2019-05-22
	 * @author vishkv
	 * The following method is used to handle BookDetailNotFoundException
	 * @return ModelAndView: To No data found page(View) Model- String: Message
	 */
	@ExceptionHandler(BookDetailNotFoundException.class)
	public ModelAndView handleBookDetailNotFoundException() {
		LOGGER.error("Resolved"+BookDetailNotFoundException.class.getName());
		return new ModelAndView("nodatafound","message","Book");
	}
}
