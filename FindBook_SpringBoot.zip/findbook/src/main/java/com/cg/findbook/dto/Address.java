package com.cg.findbook.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Address is a POJO that contains details of Address
 * @author vishkv
 * @version 1.0
 * @since 2019-04-10 
 */
@Entity
public class Address {

	@Id
	@Column(name = "address_id", updatable = false, nullable = false)
	private int id;
	private String houseNo;
	private String area;
	private String city;
	private String state;
	private Long pincode;

	public Address() {

	}

	public Address(String houseNo, String area, String city, String state, Long pincode) {
		super();
		this.houseNo = houseNo;
		this.area = area;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
	}
	public String getHouseNo() {
		return houseNo;
	}
	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Long getPincode() {
		return pincode;
	}
	public void setPincode(Long pincode) {
		this.pincode = pincode;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "" + houseNo + ", " + area + ", " + city + ", " + state + ", "
				+ pincode ;
	}

}
