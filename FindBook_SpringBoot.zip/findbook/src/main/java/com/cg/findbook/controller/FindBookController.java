package com.cg.findbook.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Category;
import com.cg.findbook.dto.Customer;
import com.cg.findbook.exceptions.BookDetailNotFoundException;
import com.cg.findbook.exceptions.CustomerDetailNotFoundException;
import com.cg.findbook.service.CustomerService;

/**
 * Rest Controller Implementation. 
 * @author vishkv
 * @version 1.0
 * @since 2019-05-22 
 */
@RestController
@RequestMapping("/fb")
public class FindBookController {
	
	private static final Logger LOGGER = Logger.getLogger(FindBookController.class);
	
	@Autowired
	CustomerService customerService;
	
	/**
	 * Last modified on 2019-05-24
	 * @author vishkv
	 * The following method is used to add customer 
	 * @param ModelAtribute: Customer
	 * @return Customer: Details of the added Customer
	 */
	@RequestMapping(method=RequestMethod.POST, value="/add")
	@CrossOrigin(origins="http://localhost:4200")
	public Customer addCustomer(@ModelAttribute Customer customer) {
		customerService.add(customer);
		return customer;
	}
	
	/**
	 * Last modified on 2019-05-24
	 * @author vishkv
	 * The following method is used to add book 
	 * @param ModelAtribute: Book, Integer CustomerId(id of customer whose book is added)
	 * @return Customer: Details of the Customer whose book was added.
	 * @throws CustomerDetailNotFoundException 
	 */
	@RequestMapping(method=RequestMethod.POST, value="/addbook")
	@CrossOrigin(origins="http://localhost:4200")
	public  ResponseEntity<Customer> addBook(@ModelAttribute Book book,@RequestParam("cid") Integer cid) throws CustomerDetailNotFoundException {
		Customer customer;
			customer = customerService.assignBookToCustomer(book, cid);
			return new ResponseEntity(customer,HttpStatus.OK);
	}
	
	/**
	 * Last modified on 2019-05-24
	 * @author vishkv
	 * The following method is used to fetch all books
	 * @return List<Book> : all the books available.
	 * @throws BookDetailNotFoundException 
	 */
	@RequestMapping(method=RequestMethod.GET, value="/showallbooks")
	@CrossOrigin(origins="http://localhost:4200")
	public  ResponseEntity<List<Book>> getBooks() throws BookDetailNotFoundException {
		List<Book> books=new ArrayList<Book>();
	
				books = customerService.getAllBooks();
				return new ResponseEntity(books,HttpStatus.OK);
	}
	
	/**
	 * Last modified on 2019-05-24
	 * @author vishkv
	 * The following method is used to search Customers by category
	 * @param String category
	 * @return List<Customer> falling in the search requirement 
	 * @throws CustomerDetailNotFoundException 
	 */
	@RequestMapping(method=RequestMethod.GET, value="/searchcat")
	@CrossOrigin(origins="http://localhost:4200")
	public  ResponseEntity<List<Customer>> searchCustCat(@RequestParam("category") String category) throws CustomerDetailNotFoundException {
		List<Customer> cust;
		
			cust = customerService.searchCustomersByCategory(category);
			return new ResponseEntity(cust,HttpStatus.OK);
	}
	
	/**
	 * Last modified on 2019-05-24
	 * @author vishkv
	 * The following method is used to search books by category.
	 * @param String category
	 * @return List<Customer> falling in the search requirement 
	 * @throws BookDetailNotFoundException 
	 */
	@RequestMapping(method=RequestMethod.GET, value="/searchbookbycat")
	public  ResponseEntity<List<Book>> searchBookCat(@RequestParam("category") String category) throws BookDetailNotFoundException {
		List<Book> books;
		books = customerService.searchBooksByCategory(category);
		return new ResponseEntity(books,HttpStatus.OK);
	}
	
	/**
	 * Last modified on 2019-05-24
	 * @author vishkv
	 * The following method is used to search Customers by book name 
	 * @param String bookName
	 * @return List<Customer> falling in the search requirement 
	 * @throws CustomerDetailNotFoundException 
	 */
	@RequestMapping(method=RequestMethod.GET, value="/searchcustbname")
	public  ResponseEntity<List<Book>> searchCustBook(@RequestParam("bname") String bookName) throws CustomerDetailNotFoundException {
		List<Customer> customers;
		customers = customerService.searchCustomersByBookName(bookName);
		return new ResponseEntity(customers,HttpStatus.OK);
	}
	
	/**
	 * Last modified on 2019-05-24
	 * @author vishkv
	 * The following method is used to get all the categories
	 * @return List<Category> : all the categories.
	 */
	@RequestMapping(method=RequestMethod.GET, value="/getcategory")
	public  ResponseEntity<List<Category>> getCategory() {
		return new ResponseEntity(Category.values(),HttpStatus.OK);
			
	}
	
	/**
	 * Last modified on 2019-05-22
	 * @author vishkv
	 * Exception Handler Method
	 * The following method is used to handle CustomerDetailNotFoundException
	 * @param CustomerDetailNotFoundException
	 * @return ResponseEntity: NOT FOUND
	 */
	@ExceptionHandler(CustomerDetailNotFoundException.class)
	public ResponseEntity handleCustomerDetailNotFoundException(CustomerDetailNotFoundException ex) {
		LOGGER.info("Resolved "+CustomerDetailNotFoundException.class.getName()+" :"+ex.getMessage());
		return new  ResponseEntity(ex.getMessage(),HttpStatus.NOT_FOUND);
	}
	
	/**
	 * Last modified on 2019-05-22
	 * @author vishkv
	 * Exception Handler Method
	 * The following method is used to handle BookDetailNotFoundException
	 * @param BookDetailNotFoundException
	 * @return ResponseEntity: NOT FOUND
	 */
	@ExceptionHandler(BookDetailNotFoundException.class)
	public ResponseEntity handleBookDetailNotFoundException(BookDetailNotFoundException ex) {
		LOGGER.info("Resolved "+BookDetailNotFoundException.class.getName()+" :"+ex.getMessage());
		return new  ResponseEntity(ex.getMessage(),HttpStatus.NOT_FOUND);
	}

}
