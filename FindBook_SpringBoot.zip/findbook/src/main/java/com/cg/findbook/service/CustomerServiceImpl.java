package com.cg.findbook.service;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.findbook.dao.CustomerRepository;
import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Customer;
import com.cg.findbook.exceptions.BookDetailNotFoundException;
import com.cg.findbook.exceptions.CustomerDetailNotFoundException;

/**
 * Service Layer Implementation. 
 * @author vishkv
 * @version 1.0
 * @since 2019-04-10 
 */
@Service("customerService")
@Transactional
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	private CustomerRepository  customerRepository;

	private static final Logger LOGGER = Logger.getLogger(CustomerServiceImpl.class);
	/*
	 * The static variables customerCount and bookCount are used to generate ID for respected entities. These are initialized 
	 * to a particular value. 
	 */

	private static int bookCount=1300;
	private static int customerCount=1190;
	private static int addressCount=12090;

	public  CustomerServiceImpl() {

	}
	/**
	 * Last modified on 2019-05-02
	 * @author vishkv
	 * The following method is used to add a new Customer 
	 * @param customer This is the Customer to be added
	 * @return Customer
	 */
	@Override
	public Customer add(Customer customer)  {
		customer.getAddress().setId(addressCount);
		addressCount++;
		customer.setId(customerCount);
		customerCount++;
		LOGGER.info("Sending data to repository: "+customer);
		customer=customerRepository.save(customer);
		return customer;

	}
	
	/**
	 * Last modified on 2019-05-24
	 * The assignBookToCustomer() Method is used to add a new Book and assign that book to the mentioned customer 
	 * @author vishkv
	 * @param book This is the book to be added
	 * @param customerId This is the id of the Customer to whom the book must be added
	 * @return Customer
	 * @exception CustomerDetailNotFoundException  thrown when details of Customer is not found.
	 * */
	@Override
	public Customer assignBookToCustomer(Book book, int id) throws CustomerDetailNotFoundException {
		Customer customer=customerRepository.findCustomerById(id);
		if(customer!=null) {
			book.setId(bookCount);
			bookCount++;
			List<Book> books=customer.getBooks();
			books.add(book);
			customer.setBooks(books);
			LOGGER.info("Sending data to repository: "+customer);
			customer=customerRepository.save(customer);
			return customer;
		}
		throw new CustomerDetailNotFoundException("Invalid Customer Id. Please check and Try Again");
	}
	
	/** 
	 * Last modified on 2019-05-02
	 * The following Method is used to search the customers who have a particular book: It is a keyword search
	 * @author vishkv
	 * @param bookName This string acts as the keyword for searching.
	 * @return List of Customers having the book with parameter bookName
	 * @exception CustomerDetailNotFoundException  thrown when details of Customer is not found.
	 * @see {@link CustomerDetailNotFoundException}  
	 */
	@Override
	public List<Customer> searchCustomersByBookName(String bookName) throws CustomerDetailNotFoundException {
		if(!customerRepository.findCustomerByBookName(bookName).isEmpty())
			return customerRepository.findCustomerByBookName(bookName);
		LOGGER.warn("No data returned ");
		throw new CustomerDetailNotFoundException("No readers Found with Book: "+bookName);
	}
	
	/** 
	 * Last modified on 2019-05-02
	 * The following Method is used to search the customers who have a particular category book
	 * @author vishkv
	 * @param category This string contains the category to be search.
	 * @return List of Customers having the book that falls in the particular category
	 * @exception CustomerDetailNotFoundException thrown when details of Customer is not found.
	 * @see {@link CustomerDetailNotFoundException}  
	 */
	@Override
	public List<Customer> searchCustomersByCategory(String category) throws CustomerDetailNotFoundException {
		if(!customerRepository.findCustomerByBookCategory(category).isEmpty())
			return customerRepository.findCustomerByBookCategory(category);
		LOGGER.warn("No data returned ");
		throw new CustomerDetailNotFoundException("No readers found in Category: "+category);
	}
	
	/** 
	 * Last modified on 2019-05-02
	 * The following Method is used to search the customers who have a particular category book
	 * @author vishkv
	 * @param category This string contains the category to be search.
	 * @return List of Books that falls in the particular category
	 * @exception CustomerDetailNotFoundException thrown when details of Customer is not found.
	 * @see {@link CustomerDetailNotFoundException}  
	 */
	@Override
	public List<Book> searchBooksByCategory(String category) throws BookDetailNotFoundException {
		if(!customerRepository.findBooksByCategory(category).isEmpty())
			return customerRepository.findBooksByCategory(category);
		LOGGER.warn("No data returned ");
		throw new BookDetailNotFoundException("No Books Found in Category "+category);
	}
	
	/** 
	 * Last modified on 2019-05-02
	 * The following Method is used to retrieve all the books.
	 * @author vishkv
	 * @return List of all Books 
	 * @exception BookDetailNotFoundException
	 * @see {@link BookDetailNotFoundException}  
	 */
	@Override
	public List<Book> getAllBooks() throws BookDetailNotFoundException {
		if(!customerRepository.findAllBook().isEmpty())
			return customerRepository.findAllBook();
		LOGGER.warn("No data returned ");
		throw new BookDetailNotFoundException("No Books Found");
	}



}
