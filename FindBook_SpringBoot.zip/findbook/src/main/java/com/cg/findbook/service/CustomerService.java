package com.cg.findbook.service;

import java.util.List;

import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Customer;
import com.cg.findbook.exceptions.BookDetailNotFoundException;
import com.cg.findbook.exceptions.CustomerDetailNotFoundException;

/**
 * Service Interface. 
 * @author vishkv
 * @version 1.0
 * @since 2019-04-11 
 */
public interface CustomerService {

	Customer add(Customer customer)  ;
	Customer assignBookToCustomer(Book book,int id) throws CustomerDetailNotFoundException;
	List<Customer> searchCustomersByBookName(String bookName) throws CustomerDetailNotFoundException;
	List<Customer> searchCustomersByCategory(String category) throws CustomerDetailNotFoundException;
	List<Book> searchBooksByCategory(String category) throws BookDetailNotFoundException;
	List<Book> getAllBooks() throws BookDetailNotFoundException;
	
}
