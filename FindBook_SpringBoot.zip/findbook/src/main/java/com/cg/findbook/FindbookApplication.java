package com.cg.findbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main Implementation: Spring Boot Application. 
 * @author vishkv
 * @version 1.0
 * @since 2019-05-23 
 */

@SpringBootApplication
public class FindbookApplication {

	/**
	 * Last modified on 2019-05-18
	 * @author vishkv
	 * The main method is used to run the spring application
	 * @param String[]
	 */
	public static void main(String[] args) {
		SpringApplication.run(FindbookApplication.class, args);
	}

}
