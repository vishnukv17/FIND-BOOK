package com.cg.findbook.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Customer;

/**
 * Repository Interface. Contains methods that are used for data modification/retrieval(excluding spring data methods)
 * @author vishkv
 * @version 1.0
 * @since 2019-05-23 
 */
public interface CustomerRepository extends JpaRepository<Customer, Integer>{

	/** 
	 * @author vishkv
	 * Last modified on 2019-05-23
	 * The following Method is used to find the customer by Id.
	 * @param customerId This integer value is the id of customer to be searched.
	 * @return Customer having that particular id.
	 */
	public Customer findCustomerById(int id);
	
	/** 
	 * @author vishkv
	 * Last modified on 2019-05-23
	 * The following Method is used to retrieve all the books.
	 * @return List of all Books 
	 */
	@Query(DBQueries.selectAllBooks)
	public List<Book> findAllBook();
	
	/** 
	 * @author vishkv
 	 * Last modified on 2019-05-23
	 * The following Method is used to find the customers who have a particular category book
	 * @param category This string contains the category to be search.
	 * @return List of Customers having the book that falls in the particular category
	 */
	@Query(DBQueries.selectCustomerByCategory)
	public List<Customer> findCustomerByBookCategory(@Param("cat") String category);
	
	
	/** 
	 * @author vishkv
	 * Last modified on 2019-05-23
	 * The following Method is used to search the books that falls in a particular category.
	 * @param category This string contains the category to be search.
	 * @return List of Customers having the book that falls in the particular category
	 */
	@Query(DBQueries.selectBooksByCategory)
	public List<Book> findBooksByCategory(@Param("cat") String category);
	
	/** 
	 * @author vishkv
	 * Last modified on 2019-05-23
	 * The following Method is used to find the customers who have a particular book: It is a keyword case insensitive search
	 * @param bookName This string acts as the keyword for searching.
	 * @return List of Customers having the book with parameter bookName
	 */
	@Query(DBQueries.selectCustomerByBook)
	public List<Customer> findCustomerByBookName(@Param("bname") String bookName);
	
}
