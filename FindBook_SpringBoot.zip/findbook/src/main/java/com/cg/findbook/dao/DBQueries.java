package com.cg.findbook.dao;
/**
 * Query Interface. 
 * @author vishkv
 * @version 1.0
 * @since 2019-04-10
 * Contains all the JPQL queries that are used. 
 */
public interface DBQueries {
		
		public static final String selectAllBooks="From Book";
		public static final String selectBooksByCategory="From Book b where b.category= :cat";
		public static final String selectCustomerByBook="SELECT DISTINCT c From Customer c, in (c.books) b where b.name like %:bname%";
		public static final String selectCustomerByCategory="SELECT DISTINCT c From Customer c, in (c.books) b where b.category= :cat";
}
