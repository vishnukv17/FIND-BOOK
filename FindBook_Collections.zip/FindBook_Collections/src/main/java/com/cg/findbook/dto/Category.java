package com.cg.findbook.dto;

public enum Category {
FICTION,CLASSICS,EDUCATION,JOURNALS,SCIENCE;
}
