package com.cg.findbook.service;
import java.util.List;
import com.cg.findbook.dao.CustomerRepositoryImpl;
import com.cg.findbook.dao.CustomerRepository;
import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Customer;
import com.cg.findbook.exceptions.BookDetailNotFoundException;
import com.cg.findbook.exceptions.CustomerDetailNotFoundException;

public class CustomerServiceImpl implements CustomerService{
	private CustomerRepository  repository;
	private static int customerCount=0;
	private static int bookCount=0;
	public  CustomerServiceImpl() {
		repository=new CustomerRepositoryImpl();
	}
	public Customer add(Customer customer) {
		customerCount++;
		customer.setId(customerCount);
		return repository.save(customer);
	}

	public Customer assignBookToCustomer(Book book, int customerId) throws CustomerDetailNotFoundException {
		
		Customer customer=repository.findCustomerById(customerId);
		if(customer!=null) {
			bookCount++;
			List<Book> bookList=customer.getBooks();
			book.setId(bookCount);
			bookList.add(book);
			customer.setBooks(bookList);
			//return repository.save(customer);
			return customer;
		}
		throw new CustomerDetailNotFoundException("Id not found!");
	}

	public List<Customer> searchCustomersByBookName(String bookName) throws CustomerDetailNotFoundException {
		if(repository.findCustomersByBook(bookName).isEmpty())
			throw new CustomerDetailNotFoundException("No match found!");
		return repository.findCustomersByBook(bookName);
	}

	public List<Customer> searchCustomersByCategory(String category) throws CustomerDetailNotFoundException {
		
		if(repository.findCustomersByCategory(category).isEmpty())
			throw new CustomerDetailNotFoundException("No match found!");
		return repository.findCustomersByCategory(category);
		
	}

	public List<Book> searchBooksByCategory(String category) throws BookDetailNotFoundException {
		
		if(repository.findBooksByCategory(category).isEmpty())
			throw new BookDetailNotFoundException("No books found in this category!");
		return repository.findBooksByCategory(category);
	}

	public List<Book> getAllBooks() throws BookDetailNotFoundException {
		
		if(repository.getAllBooks().isEmpty())
			throw new BookDetailNotFoundException("No books found!");
		return(repository.getAllBooks());
	}

}
