package com.cg.findbook.ui;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.findbook.dto.Address;
import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Category;
import com.cg.findbook.dto.Customer;
import com.cg.findbook.exceptions.BookDetailNotFoundException;
import com.cg.findbook.exceptions.CustomerDetailNotFoundException;
import com.cg.findbook.service.CustomerServiceImpl;
import com.cg.findbook.service.CustomerService;

public class MyApplication {

	public static void main(String[] args) {

		CustomerService service=new CustomerServiceImpl();
		List<Customer> customers= new ArrayList<Customer>();

		Scanner sc=new Scanner(System.in);
		String bookName=null;
		String category=null;
		int choice=0;
		do {

			print();
			choice=sc.nextInt();
			switch(choice) {
			case 1: 
				//auto input
				/*List<Book> books=new ArrayList<Book>();
				List<Book> booksOne=new ArrayList<Book>();
				books.add(new Book(1,"Histology of Pains","PSYCHOLOGY","Barna Cherian","Independent"));
				books.add(new Book(2,"Brief History of Time","PHYSICS","Stephen Hawking","Bantam Books"));
				booksOne.add(new Book(3,"XYZ","ABC","ASD","QWE"));
				booksOne.add(new Book(4,"David Copperfield","CLASSICS","Charles Dickens","QW"));
				Customer customer=new Customer(1,"Barna", "barna.cherian@gmail.com", new BigInteger("9545205191"), new Address("302","Khojgaon", "Ambernath", "Maharashtra", 421501),books);
				customer=service.add(customer);
				customer=new Customer(2,"Vishnu", "vishnukv212@gmail.com", new BigInteger("9744450427"), new Address("Valyedath House","Trichambaram", "Taliparamba", "Kerala", 670141),booksOne);
				customer=service.add(customer);*/

				//user input code below
				List<Book> books=new ArrayList<Book>();
				sc.nextLine();
				System.out.println("Enter  Name: ");
				String name=sc.nextLine();
				System.out.println("Enter Email: ");
				String email=sc.nextLine();
				System.out.println("Enter Phone: ");
				String phone=sc.nextLine();
				System.out.println("Enter  House No: ");
				String houseNo=sc.nextLine();
				System.out.println("Enter Area: ");
				String area=sc.nextLine();
				System.out.println("Enter City: ");
				String city=sc.nextLine();
				System.out.println("Enter State: ");
				String state=sc.nextLine();
				System.out.println("Enter Pincode: ");
				long pincode=sc.nextLong();
				Address ad=new Address(houseNo, area, city, state, pincode);
				Customer customer=new Customer(name,email,new BigInteger(phone),ad,books);
				customer=service.add(customer);
				System.out.println("Details added! Your ID is "+customer.getId());
				break;
			case 2: 
				sc.nextLine();
				System.out.println("Enter Book Name: ");
				String bName=sc.nextLine();
				category=readCategory();
				sc.nextLine();
				System.out.println("Enter  Author: ");
				String author=sc.nextLine();
				System.out.println("Enter  Publisher: ");
				String publisher=sc.nextLine();
				System.out.println("Enter customer id: ");
				int custId=sc.nextInt();
				try {
					service.assignBookToCustomer(new Book(bName,category,author,publisher),custId);
				} catch (CustomerDetailNotFoundException e) { 
					System.out.println(e.getMessage());
				}
				break;
			case 3: 
				try {
					books=service.getAllBooks();
					for (Book bookTwo : books) 
						System.out.println(bookTwo);
				} catch (BookDetailNotFoundException e1) {
					System.out.println(e1.getMessage());
				}
				break;
			case 4: 
				sc.nextLine();
				System.out.println("Enter the Book name: ");
				bookName=sc.nextLine();
				try {
					customers=service.searchCustomersByBookName(bookName);
					for (Customer customerTwo : customers) 
						System.out.println(customerTwo);
				} catch (CustomerDetailNotFoundException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 5: 
				sc.nextLine();
				category=readCategory();
				try {
					customers=service.searchCustomersByCategory(category);
					for (Customer customerTwo : customers) 
						System.out.println(customerTwo);
				} catch (CustomerDetailNotFoundException e) {
					System.out.println(e.getMessage());
				}

				break;
			case 6:
				sc.nextLine();
				System.out.println("Enter the Book Category: ");
				category=readCategory();
				try {
					books=service.searchBooksByCategory(category);
					for (Book bookTwo : books) 
						System.out.println(bookTwo);
				} catch (BookDetailNotFoundException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 7: break;
			
			default: System.out.println("Wrong choice");
			}
		}while(choice!=7);
		sc.close();
	}	
	static void print() {
		System.out.println("1. Add new Customer");
		System.out.println("2. Assign new Book ");
		System.out.println("3. View All Books");
		System.out.println("4. Search Book Owners by book name ");
		System.out.println("5. Search Book Owners by category");
		System.out.println("6. Search Books by category");
		System.out.println("7. Exit");
	}
	static String readCategory() {
		Scanner sc=new Scanner(System.in);
		int i=1;
		String category=null;
		for (Category cat : Category.values()) {
			System.out.println(i+". "+cat);
			i++;
		}
		System.out.println("Select  Category: ");
		int choiceCategory=sc.nextInt();
		switch(choiceCategory) {
		case 1: category=Category.FICTION.toString();
				break;
		case 2: category=Category.CLASSICS.toString();
				break;
		case 3: category=Category.EDUCATION.toString();
				break;
		case 4: category=Category.JOURNALS.toString();
				break;
		case 5: category=Category.SCIENCE.toString();
				break;
		default: System.out.println("Wrong choice!");
		}
		return category;
	}
}
