package com.cg.findbook.util;
import com.cg.findbook.dto.*;
import java.util.ArrayList;
import java.util.List;

public class DBUtil {
	public static List<Customer> customerList= new ArrayList<Customer>();
	
}
