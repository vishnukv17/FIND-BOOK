package com.cg.findbook.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Customer;
import com.cg.findbook.util.DBUtil;

public class CustomerRepositoryImpl implements CustomerRepository{
	List<Customer> customerData;
	List<Book> bookData;
	public Customer save(Customer customer) {
		/*Iterator<Customer> iter=DBUtil.customerList.iterator();
		while(iter.hasNext())
			if(iter.next().getId()==customer.getId()) 
				iter.remove();*/
		DBUtil.customerList.add(customer);
		return customer;
	}

	public List<Customer> findCustomersByCategory(String category) {
		customerData=new ArrayList<Customer>();
		bookData=new ArrayList<Book>();
		for (Customer customer : DBUtil.customerList) {
			List<Book> bookList=customer.getBooks();
			for (Book book : bookList) 
				if(book.getCategory().toLowerCase().contains(category.toLowerCase())&& (!customerData.contains(customer))) 
					customerData.add(customer);
		}
		return customerData;
	}

	public List<Customer> findCustomersByBook(String bookName) {
		customerData=new ArrayList<Customer>();
		bookData=new ArrayList<Book>();
		for (Customer customer : DBUtil.customerList) {
			List<Book> bookList=customer.getBooks();
			for (Book book : bookList) 
				if(book.getName().toLowerCase().contains(bookName.toLowerCase())&& (!customerData.contains(customer))) 
					customerData.add(customer);
		}
		return customerData;
	}

	public Customer findCustomerById(int customerId) {
		for (Customer customer : DBUtil.customerList) 
			if(customer.getId()==customerId) 
				return customer;
		return null;
	}

	public List<Book> getAllBooks() {
		customerData=new ArrayList<Customer>();
		bookData=new ArrayList<Book>();
		for (Customer customers : DBUtil.customerList) {
			List<Book> bookList=customers.getBooks();
				for (Book book : bookList) {
					bookData.add(book);
				}
		}
		return bookData;
	}

	public List<Book> findBooksByCategory(String category) {
	
		List<Book> bookList= new ArrayList<Book>();
		bookData=getAllBooks();
		for (Book book : bookData) 
			if(book.getCategory().toLowerCase().contains(category.toLowerCase())&& (!bookList.contains(book))) 
				bookList.add(book);
		return bookList;
	}

}
