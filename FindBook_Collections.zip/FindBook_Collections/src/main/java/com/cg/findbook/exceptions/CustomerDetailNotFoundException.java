package com.cg.findbook.exceptions;

@SuppressWarnings("serial")
public class CustomerDetailNotFoundException extends Exception {
	
	public CustomerDetailNotFoundException() {
		super();
	}
	public CustomerDetailNotFoundException(String exceptionMessage) {
		super(exceptionMessage);
	}

}
