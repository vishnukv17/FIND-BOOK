package com.cg.findbook.service;
import java.util.ArrayList;
import java.util.List;

import com.cg.findbook.dao.CustomerRepository;
import com.cg.findbook.dao.CustomerRepositoryImpl;
import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Customer;
import com.cg.findbook.exceptions.BookDetailNotFoundException;
import com.cg.findbook.exceptions.ConnectionException;
import com.cg.findbook.exceptions.CustomerDetailNotFoundException;
import com.cg.findbook.exceptions.DataModificationException;

public class CustomerServiceImpl implements CustomerService{
	private CustomerRepository  repository;
	public  CustomerServiceImpl() {
		repository=new CustomerRepositoryImpl();
	}
	public Customer add(Customer customer) throws ConnectionException, DataModificationException {
		
		return repository.save(customer);
	}

	public Customer assignBookToCustomer(Book book, int customerId) throws CustomerDetailNotFoundException, ConnectionException, DataModificationException {
		
		Customer customer=repository.findCustomerById(customerId);
		if(customer!=null) {
			List<Book> bookList=new ArrayList<Book>();
			bookList.add(book);
			customer.setBooks(bookList);
			return repository.save(customer);
		}
		throw new CustomerDetailNotFoundException("Id not found!");
	}

	public List<Customer> searchCustomersByBookName(String bookName) throws CustomerDetailNotFoundException, ConnectionException {
		if(repository.findCustomersByBook(bookName).isEmpty())
			throw new CustomerDetailNotFoundException("No match found!");
		return repository.findCustomersByBook(bookName);
	}

	public List<Customer> searchCustomersByCategory(String category) throws CustomerDetailNotFoundException, ConnectionException {
		
		if(repository.findCustomersByCategory(category).isEmpty())
			throw new CustomerDetailNotFoundException("No match found!");
		return repository.findCustomersByCategory(category);
		
	}

	public List<Book> searchBooksByCategory(String category) throws BookDetailNotFoundException, ConnectionException {
		
		if(repository.findBooksByCategory(category).isEmpty())
			throw new BookDetailNotFoundException("No books found in this category!");
		return repository.findBooksByCategory(category);
	}

	public List<Book> getAllBooks() throws BookDetailNotFoundException, ConnectionException {
		
		if(repository.getAllBooks().isEmpty())
			throw new BookDetailNotFoundException("No books found!");
		return(repository.getAllBooks());
	}

}
