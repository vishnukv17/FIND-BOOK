package com.cg.findbook.exceptions;

@SuppressWarnings("serial")
public class DataModificationException extends Exception {
	public DataModificationException() {
	
	}
	public DataModificationException(String message) {
		super(message);
	}

}
