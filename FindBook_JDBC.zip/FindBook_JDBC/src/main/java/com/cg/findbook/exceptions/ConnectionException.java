package com.cg.findbook.exceptions;

@SuppressWarnings("serial")
public class ConnectionException extends Exception {
	public ConnectionException() {
	
	}
	public ConnectionException(String message) {
		super(message);
	}

}
