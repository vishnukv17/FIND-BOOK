package com.cg.findbook.dto;

public class Address {

	private String houseNo,area,city,state;
	private long pincode;
	
	public Address() {
		houseNo=null;
		area=null;
		city=null;
		state=null;
		pincode=0;
	}
	
	public Address(String houseNo, String area, String city, String state, long pincode) {
		super();
		this.houseNo = houseNo;
		this.area = area;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
	}
	public String getHouseNo() {
		return houseNo;
	}
	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public long getPincode() {
		return pincode;
	}
	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "" + houseNo + ", " + area + ", " + city + ", " + state + ", "
				+ pincode ;
	}
	
}
