package com.cg.findbook.dao;

public interface DBQueries {
	public static final String insertCustomer="insert into customer_details(customer_name,customer_email,customer_phone,address_id) values(?,?,?,?)";
	public static final String insertAddress="insert into address_details(house_no,area,city,state,pincode) values(?,?,?,?,?)";
	public static final String selectAddressId="select max(id) from address_details";
	public static final String selectMaxCustomerId="select max(customer_id) from customer_details";
	public static final String insertBooks="insert into book_details(book_name,book_category,book_author,book_publisher,customer_id) values(?,?,?,?,?) ";
	public static final String selectCustomer="select customer_id from customer_details where customer_id=?";
	public static final String selectCustomerByCategory="select distinct c.customer_id from customer_details c inner join address_details a on c.address_id=a.id where c.customer_id in(select b.customer_id from book_details b where  b.book_category=?) group by c.customer_id"; 
	public static final String selectCustomerByBook="select distinct c.customer_id from customer_details c inner join address_details a on c.address_id=a.id where c.customer_id in(select b.customer_id from book_details b where b.book_name like ? ) group by c.customer_id ";
	public static final String selectBookByCategory="select * from book_details where book_category=?";
	public static final String selectBook="select * from book_details";
	public static final String findCustomer="select c.customer_id,c.customer_name,c.customer_email,c.customer_phone,a.house_no,a.area,a.city,a.state,a.pincode from customer_details c inner join address_details a on c.address_id=a.id where c.customer_id=?";
	public static final String findCustomerBooks="select b.book_id,b.book_name,b.book_category,b.book_author,b.book_publisher,b.customer_id from book_details b where b.customer_id=?";
}
