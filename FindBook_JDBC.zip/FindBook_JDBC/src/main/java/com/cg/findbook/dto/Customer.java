package com.cg.findbook.dto;


import java.math.BigInteger;
import java.util.List;

public class Customer {

	
	private int id;
	private String name,email;
	private BigInteger phone;
	private Address address;
	private List<Book> books;
	public Customer() {
		this.id = 0;
		this.name = null;
		this.email = null;
		this.phone = null;
		this.address = null;
		this.books = null;
		
	}
	public Customer(int id,String name, String email, BigInteger phone, Address address, List<Book> books) {
		super();
		this.id=id;
		this.name = name;
		this.email = email;
		this.phone = phone;
		this.address = address;
		this.books = books;
	}
	public Customer(String name, String email, BigInteger phone, Address address, List<Book> books) {
		super();
	
		this.name = name;
		this.email = email;
		this.phone = phone;
		this.address = address;
		this.books = books;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public BigInteger getPhone() {
		return phone;
	}
	public void setPhone(BigInteger phone) {
		this.phone = phone;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public List<Book> getBooks() {
		return books;
	}
	public void setBooks(List<Book> books) {
		this.books = books;
	}
	@Override
	public String toString() {
		return "Customer: \n id:" + id + "\n name:" + name + ",\n email:" + email + ",\n phone:" + phone + ",\n address:"
				+ address + ",\n books: " + books ;
	}
	
}
