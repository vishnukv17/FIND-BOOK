package com.cg.findbook.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import java.util.Properties;

import com.cg.findbook.exceptions.ConnectionException;
public class DBUtil {
	static Connection conn;
	public static Connection getConnection() throws ConnectionException  {
		
		InputStream it=null;
		String driver=null,url=null,uname=null,upass=null;
		try {
			it=new FileInputStream("src/main/resources/findbook_exp.properties");
			Properties prop=new Properties();
			prop.load(it);
			if(prop!=null) {
			driver=prop.getProperty("jdbc.driver");
			url=prop.getProperty("jdbc.url");
			uname=prop.getProperty("jdbc.username");
			upass=prop.getProperty("jdbc.password");
			Class.forName(driver);
			conn=DriverManager.getConnection(url, uname, upass);
			}
		} catch (FileNotFoundException e) {
			throw new ConnectionException("Connection not established!");
		} catch (ClassNotFoundException e) {
			throw new ConnectionException("Connection not established!");
		} catch (SQLException e) {
			throw new ConnectionException("Connection not established!");
		} catch (IOException e) {	
			throw new ConnectionException("Connection not established!");
		}
		return conn;
	}
}
