package com.cg.findbook.ui;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.cg.findbook.dto.Address;
import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Category;
import com.cg.findbook.dto.Customer;
import com.cg.findbook.exceptions.BookDetailNotFoundException;
import com.cg.findbook.exceptions.ConnectionException;
import com.cg.findbook.exceptions.CustomerDetailNotFoundException;
import com.cg.findbook.exceptions.DataModificationException;
import com.cg.findbook.service.CustomerService;
import com.cg.findbook.service.CustomerServiceImpl;

public class MyApplication {

	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {

		CustomerService service=new CustomerServiceImpl();
		List<Customer> customers= new ArrayList<Customer>();

	
		String bookName=null;
		String category=null;
		int choice=0;
		do {

			print();
			choice=sc.nextInt();
			switch(choice) {
			case 1: 
				List<Book> books=new ArrayList<Book>();
				sc.nextLine();
				System.out.println("Enter  Name: ");
				String name=sc.nextLine();
				System.out.println("Enter Email: ");
				String email=sc.nextLine();
				System.out.println("Enter Phone: ");
				String phone=sc.nextLine();
				System.out.println("Enter  House No: ");
				String houseNo=sc.nextLine();
				System.out.println("Enter Area: ");
				String area=sc.nextLine();
				System.out.println("Enter City: ");
				String city=sc.nextLine();
				System.out.println("Enter State: ");
				String state=sc.nextLine();
				System.out.println("Enter Pincode: ");
				long pincode=sc.nextLong();
				Address address=new Address(houseNo, area, city, state, pincode);
				Customer customer=new Customer(name,email,new BigInteger(phone),address,books);
				try {
					customer=service.add(customer);
				} catch (ConnectionException e2) {
					System.out.println(e2.getMessage());
				} catch (DataModificationException e) {
					System.out.println(e.getMessage());
				}
				System.out.println("Details added! Your ID is "+customer.getId());
				break;
			case 2: 
				sc.nextLine();
				System.out.println("Enter Book Name: ");
				bookName=sc.nextLine();
				category=readCategory();
				sc.nextLine();
				System.out.println("Enter  Author: ");
				String author=sc.nextLine();
				System.out.println("Enter  Publisher: ");
				String publisher=sc.nextLine();
				System.out.println("Enter the Customer ID: ");
				int custId=sc.nextInt();
				try {
					try {
						service.assignBookToCustomer(new Book(bookName,category,author,publisher),custId);
					} catch (ConnectionException e) {
						System.out.println(e.getMessage());
					} catch (DataModificationException e) {
						System.out.println(e.getMessage());
					}
				} catch (CustomerDetailNotFoundException e) { 
					System.out.println(e.getMessage());
				}
				break;
			case 3: 
				try {
					try {
						books=service.getAllBooks();
						for (Book bookTwo : books) 
							System.out.println(bookTwo);
					} catch (ConnectionException e) {
						System.out.println(e.getMessage());
					}
					
				} catch (BookDetailNotFoundException e1) {
					System.out.println(e1.getMessage());
				}
				break;
			case 4: 
				sc.nextLine();
				System.out.println("Enter the Book name: ");
				bookName=sc.nextLine();
				try {
					customers=service.searchCustomersByBookName(bookName);
					for (Customer customerTwo : customers) 
						System.out.println(customerTwo);
				} catch (CustomerDetailNotFoundException e) {
					System.out.println(e.getMessage());
				} catch (ConnectionException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 5: 
				sc.nextLine();
				category=readCategory();
				try {
					customers=service.searchCustomersByCategory(category);
					for (Customer customerTwo : customers) 
						System.out.println(customerTwo);
				} catch (CustomerDetailNotFoundException e) {
					System.out.println(e.getMessage());
				} catch (ConnectionException e) {
					System.out.println(e.getMessage());
				}

				break;
			case 6:
				sc.nextLine();
				System.out.println("Enter the Book Category: ");
				category=readCategory();
				try {
					books=service.searchBooksByCategory(category);
					for (Book bookTwo : books) 
						System.out.println(bookTwo);
				} catch (BookDetailNotFoundException e) {
					System.out.println(e.getMessage());
				} catch (ConnectionException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 7: System.out.println("........");
					break;
			default: System.out.println("Wrong choice");
			}
		}while(choice!=7);
		sc.close();
	}	
	static void print() {
		System.out.println("******************************************");
		System.out.println("1. Add new Customer");
		System.out.println("2. Add new Book ");
		System.out.println("3. View All Books");
		System.out.println("4. Search Book Owners by book name ");
		System.out.println("5. Search Book Owners by category");
		System.out.println("6. Search Books by category");
		System.out.println("7. Exit");
		System.out.println("Enter your choice(1-7): ");
	}
	
	static String readCategory() {		//method for category selection
		int i=1;
		String category=null;
		for (Category cat : Category.values()) {  //Loop for displaying all the categories
			System.out.println(i+". "+cat);
			i++;
		}
		
		System.out.println("Select  Category: ");
		int choiceCategory=sc.nextInt();
		switch(choiceCategory) {
		case 1: category=Category.FICTION.toString();
				break;
		case 2: category=Category.CLASSICS.toString();
				break;
		case 3: category=Category.EDUCATION.toString();
				break;
		case 4: category=Category.JOURNALS.toString();
				break;
		case 5: category=Category.SCIENCE.toString();
				break;
		case 6: category=Category.OTHER.toString();
				break;
		default: System.out.println("Wrong choice!");
		}

		return category;
	}
}
