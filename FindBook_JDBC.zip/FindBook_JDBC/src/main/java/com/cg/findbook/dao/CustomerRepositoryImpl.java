package com.cg.findbook.dao;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.findbook.dto.Address;
import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Customer;
import com.cg.findbook.exceptions.ConnectionException;
import com.cg.findbook.exceptions.DataModificationException;
import com.cg.findbook.util.DBUtil;

public class CustomerRepositoryImpl implements CustomerRepository{
	List<Customer> customerData;
	List<Book> bookData;
	public Customer save(Customer customer) throws ConnectionException ,DataModificationException{
		Connection connection=null;
		PreparedStatement pstmt=null;
		ResultSet result=null;
		connection=DBUtil.getConnection();
		try {
			if(customer.getId()==0) {
				pstmt=connection.prepareStatement(DBQueries.insertAddress);
				pstmt.setString(1,customer.getAddress().getHouseNo());
				pstmt.setString(2,customer.getAddress().getArea());
				pstmt.setString(3,customer.getAddress().getCity());
				pstmt.setString(4,customer.getAddress().getState());
				pstmt.setLong(5,customer.getAddress().getPincode());
				int res=pstmt.executeUpdate();
				if(res>0) {
					int address_id=0;
					pstmt=connection.prepareStatement(DBQueries.selectAddressId);
					result=pstmt.executeQuery();
					if(result.next()) {
						address_id=result.getInt(1);
					}
					pstmt=connection.prepareStatement(DBQueries.insertCustomer);
					pstmt.setString(1,customer.getName());
					pstmt.setString(2,customer.getEmail());
					pstmt.setString(3,customer.getPhone().toString());
					pstmt.setInt(4,address_id);
					res=pstmt.executeUpdate();
					pstmt=connection.prepareStatement(DBQueries.selectMaxCustomerId);
					result=pstmt.executeQuery();
					if(result.next()) {
						customer.setId(result.getInt(1));
					}
				}
				if(res>0)
					return customer;
			}
			else {
				pstmt=connection.prepareStatement(DBQueries.selectCustomer);
				pstmt.setInt(1,customer.getId());
				result=pstmt.executeQuery();
				Book book=customer.getBooks().get(0);
				if(result.next()) {
					pstmt=connection.prepareStatement(DBQueries.insertBooks);
					pstmt.setString(1,book.getName());
					pstmt.setString(2,book.getCategory());
					pstmt.setString(3,book.getAuthor());
					pstmt.setString(4,book.getPublisher());
					pstmt.setInt(5, customer.getId());
					int res=pstmt.executeUpdate();
					if(res>0)
						return customer;
					
				}
			}
		} catch (SQLException e) {
			throw new DataModificationException("Failed to add the details!");
		}
		
		return null;
	}

	public List<Customer> findCustomersByCategory(String category) throws ConnectionException {
		Connection connection=null;
		PreparedStatement pstmt=null;
		ResultSet result=null;
		connection=DBUtil.getConnection();
		List<Customer> customers=new ArrayList<Customer>();
		try {
			pstmt=connection.prepareStatement(DBQueries.selectCustomerByCategory);
			pstmt.setString(1,category);
			result=pstmt.executeQuery();
			while(result.next()) {
				System.out.println(result.getInt(1));
				Customer customer=findCustomerById(result.getInt(1));
				customers.add(customer);
			}
			return customers;
		} catch (SQLException e) {
			return null;
		}
	}

	public List<Customer> findCustomersByBook(String bookName) throws ConnectionException {
		
		Connection connection=null;
		PreparedStatement pstmt=null;
		ResultSet result=null;
		connection=DBUtil.getConnection();
		List<Customer> customers=new ArrayList<Customer>();
		try {
			pstmt=connection.prepareStatement(DBQueries.selectCustomerByBook);
			pstmt.setString(1,"%"+bookName+"%");
			result=pstmt.executeQuery();
			while(result.next()) {
				customers.add(findCustomerById(result.getInt(1)));
			}
			return customers;
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
		return null;
	}

	public Customer findCustomerById(int customerId) throws ConnectionException {
		Customer customer=null;
		Connection connection=null;
		PreparedStatement pstmt=null;
		ResultSet result=null;
		connection=DBUtil.getConnection();
		try {
			pstmt=connection.prepareStatement(DBQueries.findCustomerBooks);
			pstmt.setInt(1,customerId);
			result=pstmt.executeQuery();
			List<Book> books=new ArrayList<Book>();
			while(result.next()) {
				books.add(new Book(result.getInt(1), result.getString(2), result.getString(3),result.getString(4),result.getString(5)));
			}
			pstmt=connection.prepareStatement(DBQueries.findCustomer);
			pstmt.setInt(1,customerId);
			result=pstmt.executeQuery();
			while(result.next()) {
				customer=new Customer(result.getInt(1),result.getString(2),result.getString(3),new BigInteger(result.getString(4)),new Address(result.getString(5),result.getString(6),result.getString(7), result.getString(8),result.getLong(9)), books);
				
			}
			return customer;
		} catch (SQLException e) {
			return null;
		}
	}

	public List<Book> getAllBooks() throws ConnectionException {
		Connection connection=null;
		PreparedStatement pstmt=null;
		ResultSet result=null;
		connection=DBUtil.getConnection();
		try {
			pstmt=connection.prepareStatement(DBQueries.selectBook);
			result=pstmt.executeQuery();
			List<Book> books=new ArrayList<Book>();
			while(result.next()) {
				books.add(new Book(result.getInt(1), result.getString(2), result.getString(3),result.getString(4),result.getString(5)));
			}
			return books;
		} catch (SQLException e) {
			return null;
		}
		
	}

	public List<Book> findBooksByCategory(String category) throws ConnectionException {
		List<Book> books=new ArrayList<Book>();
		Connection connection=null;
		PreparedStatement pstmt=null;
		ResultSet result=null;
		connection=DBUtil.getConnection();
		try {
			pstmt=connection.prepareStatement(DBQueries.selectBookByCategory);
			pstmt.setString(1,category);
			result=pstmt.executeQuery();
			
			while(result.next()) {
				books.add(new Book(result.getInt(1), result.getString(2), result.getString(3),result.getString(4),result.getString(5)));
			}
			
		} catch (SQLException e) {
			return null;
		}
		return books;
	}

}
