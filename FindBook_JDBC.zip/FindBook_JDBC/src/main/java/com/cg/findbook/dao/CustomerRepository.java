package com.cg.findbook.dao;

import java.util.List;

import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Customer;
import com.cg.findbook.exceptions.ConnectionException;
import com.cg.findbook.exceptions.DataModificationException;

public interface CustomerRepository {
	
	Customer save(Customer customer) throws ConnectionException, DataModificationException;
	List<Customer> findCustomersByCategory(String category) throws ConnectionException;
	List<Customer> findCustomersByBook(String bookName) throws ConnectionException;
	Customer findCustomerById(int id) throws ConnectionException;
	List<Book> getAllBooks() throws ConnectionException;
	List<Book> findBooksByCategory(String category) throws ConnectionException;

}
