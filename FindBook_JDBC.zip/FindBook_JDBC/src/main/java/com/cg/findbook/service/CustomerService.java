package com.cg.findbook.service;

import java.util.List;

import com.cg.findbook.dto.Book;
import com.cg.findbook.dto.Customer;
import com.cg.findbook.exceptions.BookDetailNotFoundException;
import com.cg.findbook.exceptions.ConnectionException;
import com.cg.findbook.exceptions.CustomerDetailNotFoundException;
import com.cg.findbook.exceptions.DataModificationException;



public interface CustomerService {

	Customer add(Customer customer) throws ConnectionException, DataModificationException  ;
	Customer assignBookToCustomer(Book book,int id) throws CustomerDetailNotFoundException, ConnectionException, DataModificationException;
	List<Customer> searchCustomersByBookName(String bookName) throws CustomerDetailNotFoundException, ConnectionException;
	List<Customer> searchCustomersByCategory(String category) throws CustomerDetailNotFoundException, ConnectionException;
	List<Book> searchBooksByCategory(String category) throws BookDetailNotFoundException, ConnectionException;
	List<Book> getAllBooks() throws BookDetailNotFoundException, ConnectionException;
}
